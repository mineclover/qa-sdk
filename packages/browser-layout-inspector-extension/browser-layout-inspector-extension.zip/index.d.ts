import { ElementLayoutInspection, RelativePosition } from 'browser-layout-inspector';

interface ViewportPoint {
    readonly x: number;
    readonly y: number;
}
interface RulerMeasurement {
    readonly start: ViewportPoint;
    readonly end: ViewportPoint;
    readonly width: number;
    readonly height: number;
    readonly distance: number;
    /** Clockwise from the viewport's positive horizontal axis. */
    readonly angle: number;
}
interface ElementSummary {
    readonly selector: string;
    readonly tagName: string;
    readonly text: string | null;
}
/** Browser context needed to replay or compare a viewport-relative measurement. */
interface PageMeasurementEnvironment {
    readonly url: string;
    readonly viewportCssPx: Readonly<{
        readonly width: number;
        readonly height: number;
    }>;
    readonly scrollCssPx: Readonly<{
        readonly x: number;
        readonly y: number;
    }>;
    readonly devicePixelRatio: number;
    readonly visualViewport: Readonly<{
        readonly width: number;
        readonly height: number;
        readonly scale: number;
    }> | null;
}
interface PageToolState {
    readonly environment: PageMeasurementEnvironment;
    readonly pickerMode: 'select' | 'measure' | 'ruler' | null;
    readonly selected: ElementSummary | null;
    readonly inspection: ElementLayoutInspection | null;
    readonly measurement: {
        readonly anchor: ElementSummary;
        readonly target: ElementSummary;
        readonly relative: RelativePosition;
    } | null;
    /** Free-drag viewport ruler. It measures screen points, independent of DOM elements. */
    readonly ruler: RulerMeasurement | null;
    readonly rulerSnapEnabled: boolean;
    /** Viewport-fixed reference lines retained for this tab session. */
    readonly guides: Readonly<{
        readonly vertical: readonly number[];
        readonly horizontal: readonly number[];
    }>;
    readonly changedElementCount: number;
}
/**
 * Tab-local interaction state. Every mutation records the original inline declaration,
 * so restore only rolls back changes introduced by this extension session.
 */
declare class PageToolController {
    private readonly document;
    private readonly onStateChange?;
    private selected;
    private anchor;
    private measureTarget;
    private rulerStart;
    private rulerEnd;
    private rulerSnapEnabled;
    private readonly verticalGuides;
    private readonly horizontalGuides;
    private mode;
    private consumeNextClick;
    private readonly changes;
    private readonly overlay;
    constructor(document: Document, onStateChange?: ((state: PageToolState) => void) | undefined);
    startPicker(mode: 'select' | 'measure' | 'ruler'): void;
    setRulerSnap(enabled: boolean): void;
    pinRulerGuides(): void;
    clearRulerGuides(): void;
    applyStyle(property: string, value: string, priority?: string): void;
    hideSelected(): void;
    restoreSelected(): void;
    restoreAll(): void;
    state(): PageToolState;
    private readonly onPointerMove;
    private readonly onMouseDown;
    private readonly onMouseUp;
    private readonly onClick;
    private readonly onKeyDown;
    private readonly refreshOverlay;
    private elementFromEvent;
    private requireSelected;
    private capture;
    private restoreElement;
    private notifyStateChange;
}

interface InspectSelectorRequest {
    readonly type: 'browser-layout-inspector.inspect-selector';
    readonly selector: string;
    readonly referenceSelector?: string;
    readonly computedProperties?: readonly string[];
}
interface InspectSelectorResponse {
    readonly ok: boolean;
    readonly inspection?: ElementLayoutInspection;
    readonly error?: string;
}
type PageToolRequest = {
    readonly type: 'browser-layout-inspector.start-picker';
    readonly mode: 'select' | 'measure' | 'ruler';
} | {
    readonly type: 'browser-layout-inspector.set-ruler-snap';
    readonly enabled: boolean;
} | {
    readonly type: 'browser-layout-inspector.pin-ruler-guides';
} | {
    readonly type: 'browser-layout-inspector.clear-ruler-guides';
} | {
    readonly type: 'browser-layout-inspector.get-state';
} | {
    readonly type: 'browser-layout-inspector.apply-style';
    readonly property: string;
    readonly value: string;
    readonly priority?: string;
} | {
    readonly type: 'browser-layout-inspector.hide-selected';
} | {
    readonly type: 'browser-layout-inspector.restore-selected';
} | {
    readonly type: 'browser-layout-inspector.restore-all';
};
interface PageToolResponse {
    readonly ok: boolean;
    readonly state?: PageToolState;
    readonly error?: string;
}
type ExtensionRequest = InspectSelectorRequest | PageToolRequest;
type ExtensionResponse = InspectSelectorResponse | PageToolResponse;
declare function isInspectSelectorRequest(message: unknown): message is InspectSelectorRequest;
declare function isPageToolRequest(message: unknown): message is PageToolRequest;
declare function inspectRequest(message: InspectSelectorRequest, document: Document): InspectSelectorResponse;
declare function pageToolRequest(message: PageToolRequest, controller: PageToolController): PageToolResponse;

/**
 * Converts an inspection into copyable CSS. The first rule is the browser's final
 * computed snapshot; later rules are matched source candidates and are intentionally
 * labelled because CSSOM cannot expose a standards-based cascade winner per property.
 */
declare function formatInspectionAsCss(inspection: ElementLayoutInspection): string;

/**
 * Versioned, JSON-safe snapshot for exchanging a measurement with another tool.
 * It deliberately contains only the current page-tool state, never extension runtime data.
 */
interface BrowserLayoutInspectorExchangeV1 {
    readonly schemaVersion: 'browser-layout-inspector.exchange.v1';
    readonly exportedAt: string;
    readonly environment: PageToolState['environment'];
    readonly selected: PageToolState['selected'];
    readonly inspection: PageToolState['inspection'];
    readonly elementMeasurement: PageToolState['measurement'];
    readonly ruler: PageToolState['ruler'];
    readonly rulerSnapEnabled: boolean;
    readonly guides: PageToolState['guides'];
    readonly changedElementCount: number;
}
declare function createLayoutExchange(state: PageToolState, exportedAt?: string): BrowserLayoutInspectorExchangeV1;
/** Formats the exchange artifact with a trailing newline for a stable text-file representation. */
declare function formatLayoutExchangeJson(state: PageToolState): string;

export { type BrowserLayoutInspectorExchangeV1, type ExtensionRequest, type ExtensionResponse, type InspectSelectorRequest, type InspectSelectorResponse, type PageMeasurementEnvironment, PageToolController, type PageToolRequest, type PageToolResponse, type PageToolState, createLayoutExchange, formatInspectionAsCss, formatLayoutExchangeJson, inspectRequest, isInspectSelectorRequest, isPageToolRequest, pageToolRequest };
