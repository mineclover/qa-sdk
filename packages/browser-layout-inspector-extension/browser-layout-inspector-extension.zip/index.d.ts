import { ElementLayoutInspection, CssInspectorSnapshot, RelativePosition, RulerMeasurement } from 'browser-layout-inspector';

interface ElementSummary {
    readonly selector: string;
    readonly tagName: string;
    readonly text: string | null;
}
type PageWorkItemId = 'selection' | 'anchor' | 'target' | 'ruler';
interface PageSelectorCandidate {
    readonly selector: string;
    readonly source: 'matched-css' | 'unique' | 'fallback';
    readonly unique: boolean;
}
/** A persistent tab-local item that can be refocused or dismissed from the Side Panel. */
interface PageWorkItem {
    readonly id: PageWorkItemId;
    /** Role stays compact while the visible label is the currently chosen selector. */
    readonly role: string;
    readonly label: string;
    readonly detail: string;
    readonly active: boolean;
    readonly selectorCandidates: readonly PageSelectorCandidate[];
    readonly selectedSelector: string | null;
}
/** Browser context needed to replay or compare a viewport-relative measurement. */
interface PageMeasurementEnvironment {
    readonly url: string;
    readonly viewportCssPx: Readonly<{
        readonly width: number;
        readonly height: number;
    }>;
    readonly scrollCssPx: Readonly<{
        readonly x: number;
        readonly y: number;
    }>;
    readonly devicePixelRatio: number;
    readonly visualViewport: Readonly<{
        readonly width: number;
        readonly height: number;
        readonly scale: number;
    }> | null;
}
interface PageToolState {
    readonly environment: PageMeasurementEnvironment;
    readonly pickerMode: 'select' | 'auto-select' | 'measure' | 'ruler' | null;
    readonly selected: ElementSummary | null;
    /** Active page selections and drawings, kept independently so A/B does not replace a normal selection. */
    readonly workItems: readonly PageWorkItem[];
    readonly inspection: ElementLayoutInspection | null;
    /** Source declaration candidates and complete final computed declarations for the selected element. */
    readonly cssInspector: CssInspectorSnapshot | null;
    readonly measurement: {
        readonly anchor: ElementSummary;
        readonly target: ElementSummary;
        readonly relative: RelativePosition;
    } | null;
    /** Free-drag viewport ruler. It measures screen points, independent of DOM elements. */
    readonly ruler: RulerMeasurement | null;
    readonly rulerSnapEnabled: boolean;
    /** Viewport-fixed reference lines retained for this tab session. */
    readonly guides: Readonly<{
        readonly vertical: readonly number[];
        readonly horizontal: readonly number[];
    }>;
    readonly changedElementCount: number;
}
/**
 * Tab-local interaction state. Every mutation records the original inline declaration,
 * so restore only rolls back changes introduced by this extension session.
 */
declare class PageToolController {
    private readonly document;
    private readonly onStateChange?;
    /** Inspector focus; it may be a normal selection, A, or B. */
    private selected;
    /** Normal element selection, intentionally independent from A/B comparison state. */
    private normalSelection;
    private anchor;
    private measureTarget;
    private rulerStart;
    private rulerEnd;
    private rulerSnapEnabled;
    private readonly verticalGuides;
    private readonly horizontalGuides;
    private readonly selectedWorkSelectors;
    private mode;
    private activeWorkItem;
    private pickerCursor;
    private consumeNextClick;
    private readonly changes;
    private readonly overlay;
    constructor(document: Document, onStateChange?: ((state: PageToolState) => void) | undefined);
    startPicker(mode: 'select' | 'auto-select' | 'measure' | 'ruler'): void;
    /** Makes a work-list row the current CSS inspector target without altering its saved role. */
    focusWorkItem(id: PageWorkItemId): void;
    /** Removes just the requested tab-local selection or drawing. Removing A also clears its dependent B. */
    clearWorkItem(id: PageWorkItemId): void;
    /** Selects the display/copy selector for an existing element role without changing the underlying element. */
    setWorkItemSelector(id: Exclude<PageWorkItemId, 'ruler'>, selector: string): void;
    /** Selects an element from the DOM-tree panel and treats it as the normal selection. */
    selectTreeNode(selector: string): void;
    setRulerSnap(enabled: boolean): void;
    /** Removes only the tab-local guides produced by the most recent completed Ruler. */
    clearRulerGuides(): void;
    applyStyle(property: string, value: string, priority?: string): void;
    removeStyle(property: string): void;
    hideSelected(): void;
    restoreSelected(): void;
    restoreAll(): void;
    state(): PageToolState;
    private readonly onPointerMove;
    private readonly onMouseDown;
    private readonly onMouseUp;
    private readonly onClick;
    private readonly onKeyDown;
    private readonly refreshOverlay;
    /** A completed Ruler owns exactly its four edge guides; the next completed Ruler replaces them. */
    private replaceRulerGuides;
    private elementFromEvent;
    private requireSelected;
    private workItems;
    private selectorForWorkItem;
    private showPickerCursor;
    private clearPickerCursor;
    private requireValidProperty;
    private supports;
    private capture;
    private restoreElement;
    private notifyStateChange;
}

interface PageDomTreeNode {
    readonly selector: string;
    readonly label: string;
    readonly childCount: number;
    readonly children: readonly PageDomTreeNode[];
    readonly truncated: boolean;
}
interface PageStyleSnapshot {
    readonly css: string;
    readonly accessibleStylesheetCount: number;
    readonly inaccessibleStylesheets: readonly string[];
}
/**
 * Produces a bounded, clickable map of the inspected document. Extension overlays
 * are deliberately omitted so the tree represents the page rather than this tool.
 */
declare function collectPageDomTree(document: Document, maxDepth?: number, maxNodes?: number): PageDomTreeNode | null;
/** Returns readable author stylesheets as CSS text and reports CSSOM access failures without bypassing them. */
declare function extractPageStyles(document: Document): PageStyleSnapshot;

interface InspectSelectorRequest {
    readonly type: 'browser-layout-inspector.inspect-selector';
    readonly selector: string;
    readonly referenceSelector?: string;
    readonly computedProperties?: readonly string[];
}
interface InspectSelectorResponse {
    readonly ok: boolean;
    readonly inspection?: ElementLayoutInspection;
    readonly error?: string;
}
type PageToolRequest = {
    readonly type: 'browser-layout-inspector.start-picker';
    readonly mode: 'select' | 'auto-select' | 'measure' | 'ruler';
} | {
    readonly type: 'browser-layout-inspector.focus-work-item';
    readonly id: PageWorkItemId;
} | {
    readonly type: 'browser-layout-inspector.clear-work-item';
    readonly id: PageWorkItemId;
} | {
    readonly type: 'browser-layout-inspector.set-work-item-selector';
    readonly id: Exclude<PageWorkItemId, 'ruler'>;
    readonly selector: string;
} | {
    readonly type: 'browser-layout-inspector.select-tree-node';
    readonly selector: string;
} | {
    readonly type: 'browser-layout-inspector.set-ruler-snap';
    readonly enabled: boolean;
} | {
    readonly type: 'browser-layout-inspector.clear-ruler-guides';
} | {
    readonly type: 'browser-layout-inspector.get-state';
} | {
    readonly type: 'browser-layout-inspector.apply-style';
    readonly property: string;
    readonly value: string;
    readonly priority?: string;
} | {
    readonly type: 'browser-layout-inspector.remove-style';
    readonly property: string;
} | {
    readonly type: 'browser-layout-inspector.hide-selected';
} | {
    readonly type: 'browser-layout-inspector.restore-selected';
} | {
    readonly type: 'browser-layout-inspector.restore-all';
};
interface PageToolResponse {
    readonly ok: boolean;
    readonly state?: PageToolState;
    readonly error?: string;
}
interface PageDomTreeResponse {
    readonly ok: boolean;
    readonly domTree?: PageDomTreeNode | null;
    readonly error?: string;
}
interface PageStylesResponse {
    readonly ok: boolean;
    readonly pageStyles?: PageStyleSnapshot;
    readonly error?: string;
}
type PageOverviewRequest = {
    readonly type: 'browser-layout-inspector.get-dom-tree';
} | {
    readonly type: 'browser-layout-inspector.extract-page-styles';
};
type ExtensionRequest = InspectSelectorRequest | PageToolRequest | PageOverviewRequest;
type ExtensionResponse = InspectSelectorResponse | PageToolResponse | PageDomTreeResponse | PageStylesResponse;
declare function isInspectSelectorRequest(message: unknown): message is InspectSelectorRequest;
declare function isPageToolRequest(message: unknown): message is PageToolRequest;
declare function inspectRequest(message: InspectSelectorRequest, document: Document): InspectSelectorResponse;
declare function pageToolRequest(message: PageToolRequest, controller: PageToolController): PageToolResponse;
declare function isPageOverviewRequest(message: unknown): message is PageOverviewRequest;
declare function pageOverviewRequest(message: PageOverviewRequest, document: Document): PageDomTreeResponse | PageStylesResponse;

/**
 * Converts an inspection into copyable CSS. The first rule is the browser's final
 * computed snapshot; later rules are matched source candidates and are intentionally
 * labelled because CSSOM cannot expose a standards-based cascade winner per property.
 */
declare function formatInspectionAsCss(inspection: ElementLayoutInspection): string;

/**
 * Versioned, JSON-safe snapshot for exchanging a measurement with another tool.
 * It deliberately contains only the current page-tool state, never extension runtime data.
 */
interface BrowserLayoutInspectorExchangeV1 {
    readonly schemaVersion: 'browser-layout-inspector.exchange.v1';
    readonly exportedAt: string;
    readonly environment: PageToolState['environment'];
    readonly selected: PageToolState['selected'];
    readonly workItems: PageToolState['workItems'];
    readonly inspection: PageToolState['inspection'];
    readonly cssInspector: PageToolState['cssInspector'];
    readonly elementMeasurement: PageToolState['measurement'];
    readonly ruler: PageToolState['ruler'];
    readonly rulerSnapEnabled: boolean;
    readonly guides: PageToolState['guides'];
    readonly changedElementCount: number;
}
declare function createLayoutExchange(state: PageToolState, exportedAt?: string): BrowserLayoutInspectorExchangeV1;
/** Formats the exchange artifact with a trailing newline for a stable text-file representation. */
declare function formatLayoutExchangeJson(state: PageToolState): string;

export { type BrowserLayoutInspectorExchangeV1, type ExtensionRequest, type ExtensionResponse, type InspectSelectorRequest, type InspectSelectorResponse, type PageDomTreeNode, type PageDomTreeResponse, type PageMeasurementEnvironment, type PageOverviewRequest, type PageStyleSnapshot, type PageStylesResponse, PageToolController, type PageToolRequest, type PageToolResponse, type PageToolState, collectPageDomTree, createLayoutExchange, extractPageStyles, formatInspectionAsCss, formatLayoutExchangeJson, inspectRequest, isInspectSelectorRequest, isPageOverviewRequest, isPageToolRequest, pageOverviewRequest, pageToolRequest };
