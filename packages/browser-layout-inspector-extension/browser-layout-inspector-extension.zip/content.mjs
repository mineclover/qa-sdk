// ../browser-layout-inspector/dist/chunk-3OZR4ZTQ.js
function measureRuler(start, end) {
  const width = round(Math.abs(end.x - start.x));
  const height = round(Math.abs(end.y - start.y));
  return { start, end, width, height, distance: round(Math.hypot(width, height)), angle: round(Math.atan2(end.y - start.y, end.x - start.x) * (180 / Math.PI)) };
}
function rulerGuides(ruler) {
  return {
    vertical: uniqueSorted([ruler.start.x, ruler.end.x]),
    horizontal: uniqueSorted([ruler.start.y, ruler.end.y])
  };
}
function measureElementComparison(reference, target) {
  const verticalOverlapStart = Math.max(reference.top, target.top);
  const verticalOverlapEnd = Math.min(reference.bottom, target.bottom);
  const horizontalOverlapStart = Math.max(reference.left, target.left);
  const horizontalOverlapEnd = Math.min(reference.right, target.right);
  const gaps = [];
  if (verticalOverlapStart < verticalOverlapEnd) {
    const crossAxisCenter = (verticalOverlapStart + verticalOverlapEnd) / 2;
    if (reference.right < target.left) gaps.push({
      axis: "horizontal",
      cssPx: round(target.left - reference.right),
      start: reference.right,
      end: target.left,
      crossAxisCenter,
      from: { box: "reference", edge: "right" },
      to: { box: "target", edge: "left" }
    });
    else if (target.right < reference.left) gaps.push({
      axis: "horizontal",
      cssPx: round(reference.left - target.right),
      start: target.right,
      end: reference.left,
      crossAxisCenter,
      from: { box: "target", edge: "right" },
      to: { box: "reference", edge: "left" }
    });
  }
  if (horizontalOverlapStart < horizontalOverlapEnd) {
    const crossAxisCenter = (horizontalOverlapStart + horizontalOverlapEnd) / 2;
    if (reference.bottom < target.top) gaps.push({
      axis: "vertical",
      cssPx: round(target.top - reference.bottom),
      start: reference.bottom,
      end: target.top,
      crossAxisCenter,
      from: { box: "reference", edge: "bottom" },
      to: { box: "target", edge: "top" }
    });
    else if (target.bottom < reference.top) gaps.push({
      axis: "vertical",
      cssPx: round(reference.top - target.bottom),
      start: target.bottom,
      end: reference.top,
      crossAxisCenter,
      from: { box: "target", edge: "bottom" },
      to: { box: "reference", edge: "top" }
    });
  }
  return {
    deltaCssPx: { x: round(target.left - reference.left), y: round(target.top - reference.top) },
    cornerDeltasCssPx: {
      left: round(target.left - reference.left),
      right: round(target.right - reference.right),
      top: round(target.top - reference.top),
      bottom: round(target.bottom - reference.bottom)
    },
    directionalEdgeGapsCssPx: {
      referenceRightToTargetLeft: round(target.left - reference.right),
      referenceBottomToTargetTop: round(target.top - reference.bottom)
    },
    gaps
  };
}
function uniqueSorted(values) {
  return [...new Set(values)].sort((left, right) => left - right);
}
function round(value) {
  return Math.round(value * 100) / 100;
}

// ../browser-layout-inspector/dist/index.js
function readDeclarations(style) {
  return Array.from(style).map((property) => ({
    property,
    value: style.getPropertyValue(property).trim(),
    priority: style.getPropertyPriority(property)
  }));
}
function splitSelectorList(selectorText) {
  const selectors = [];
  let start = 0;
  let parenDepth = 0;
  let bracketDepth = 0;
  let quote = null;
  let escaped = false;
  for (let index = 0; index < selectorText.length; index += 1) {
    const character = selectorText[index];
    if (quote) {
      if (escaped) escaped = false;
      else if (character === "\\") escaped = true;
      else if (character === quote) quote = null;
      continue;
    }
    if (character === '"' || character === "'") quote = character;
    else if (character === "(") parenDepth += 1;
    else if (character === ")") parenDepth = Math.max(0, parenDepth - 1);
    else if (character === "[") bracketDepth += 1;
    else if (character === "]") bracketDepth = Math.max(0, bracketDepth - 1);
    else if (character === "," && parenDepth === 0 && bracketDepth === 0) {
      const selector2 = selectorText.slice(start, index).trim();
      if (selector2) selectors.push(selector2);
      start = index + 1;
    }
  }
  const selector = selectorText.slice(start).trim();
  if (selector) selectors.push(selector);
  return selectors;
}
function isActiveCondition(rule, view) {
  const conditionText = rule.conditionText;
  if (!conditionText) return null;
  if (typeof CSSRule !== "undefined" && rule.type === CSSRule.MEDIA_RULE) {
    return view.matchMedia(conditionText).matches ? conditionText : "inactive-media";
  }
  if (typeof CSSRule !== "undefined" && rule.type === CSSRule.SUPPORTS_RULE) {
    return CSS.supports(conditionText) ? conditionText : "inactive-supports";
  }
  return conditionText;
}
function matchesSelector(element, selector) {
  if (selector.includes("::")) return false;
  try {
    return element.matches(selector);
  } catch {
    return false;
  }
}
function readRules(element, rules, view, stylesheetHref, stylesheetLabel2, conditions, path, matches) {
  Array.from(rules).forEach((rule, index) => {
    const nextPath = [...path, index];
    const condition = isActiveCondition(rule, view);
    if (condition === "inactive-media" || condition === "inactive-supports") return;
    const nextConditions = condition ? [...conditions, condition] : conditions;
    if (typeof CSSRule !== "undefined" && rule.type === CSSRule.IMPORT_RULE) {
      const imported = rule;
      if (imported.styleSheet) {
        try {
          readRules(
            element,
            imported.styleSheet.cssRules,
            view,
            imported.href ?? null,
            imported.href ?? "(imported stylesheet)",
            nextConditions,
            nextPath,
            matches
          );
        } catch {
        }
      }
      return;
    }
    const selectorText = rule.selectorText;
    const style = rule.style;
    if (typeof selectorText === "string" && style) {
      for (const selector of splitSelectorList(selectorText)) {
        if (matchesSelector(element, selector)) {
          matches.push({
            stylesheetHref,
            stylesheetLabel: stylesheetLabel2,
            selector,
            declarations: readDeclarations(style),
            conditions: nextConditions,
            rulePath: nextPath
          });
        }
      }
      return;
    }
    const nestedRules = rule.cssRules;
    if (nestedRules) {
      readRules(element, nestedRules, view, stylesheetHref, stylesheetLabel2, nextConditions, nextPath, matches);
    }
  });
}
function stylesheetLabel(sheet, index) {
  return sheet.href ?? `inline-style-${index + 1}`;
}
function collectCssInfluences(element) {
  const document2 = element.ownerDocument;
  const view = document2.defaultView;
  if (!view) throw new Error("collectCssInfluences requires an element in a browsing context");
  const matchedSelectors = [];
  const inaccessibleStylesheets = [];
  Array.from(document2.styleSheets).forEach((sheet, index) => {
    const label = stylesheetLabel(sheet, index);
    try {
      readRules(element, sheet.cssRules, view, sheet.href ?? null, label, [], [], matchedSelectors);
    } catch {
      inaccessibleStylesheets.push({
        stylesheetHref: sheet.href,
        stylesheetLabel: label,
        reason: "css-rules-inaccessible"
      });
    }
  });
  return {
    matchedSelectors,
    inaccessibleStylesheets,
    inlineStyle: element.style ? readDeclarations(element.style) : []
  };
}
function extractComputedStyle(element, properties, pseudoElement = null) {
  const view = element.ownerDocument.defaultView;
  if (!view) throw new Error("extractComputedStyle requires an element in a browsing context");
  const computed = view.getComputedStyle(element, pseudoElement);
  const names = properties ? [...properties] : Array.from(computed);
  const snapshot = {};
  for (const property of names) snapshot[property] = computed.getPropertyValue(property).trim();
  return { pseudoElement, properties: snapshot };
}
function inspectCssDeclarations(element) {
  const influences = collectCssInfluences(element);
  const sourceDeclarations = [
    ...influences.inlineStyle.map((declaration) => ({
      ...declaration,
      source: "inline",
      stylesheetHref: null,
      stylesheetLabel: "element.style",
      selector: null,
      conditions: [],
      rulePath: null
    })),
    ...influences.matchedSelectors.flatMap((match) => match.declarations.map((declaration) => ({
      ...declaration,
      source: "author",
      stylesheetHref: match.stylesheetHref,
      stylesheetLabel: match.stylesheetLabel,
      selector: match.selector,
      conditions: match.conditions,
      rulePath: match.rulePath
    })))
  ];
  const computedDeclarations = Object.entries(extractComputedStyle(element).properties).map(([property, value]) => ({ property, value, priority: "" })).sort((left, right) => left.property.localeCompare(right.property));
  return { sourceDeclarations, computedDeclarations, inaccessibleStylesheets: influences.inaccessibleStylesheets };
}
function toRect(rect) {
  return {
    x: rect.x,
    y: rect.y,
    top: rect.top,
    right: rect.right,
    bottom: rect.bottom,
    left: rect.left,
    width: rect.width,
    height: rect.height
  };
}
function documentRect(viewport, view) {
  const x = viewport.x + view.scrollX;
  const y = viewport.y + view.scrollY;
  return { ...viewport, x, y, top: viewport.top + view.scrollY, right: viewport.right + view.scrollX, bottom: viewport.bottom + view.scrollY, left: viewport.left + view.scrollX };
}
function extractElementMetrics(element) {
  const view = element.ownerDocument.defaultView;
  if (!view) throw new Error("extractElementMetrics requires an element in a browsing context");
  const html = element;
  const viewportRect = toRect(element.getBoundingClientRect());
  return {
    viewportRect,
    documentRect: documentRect(viewportRect, view),
    clientRects: Array.from(element.getClientRects(), toRect),
    offset: { width: html.offsetWidth ?? 0, height: html.offsetHeight ?? 0, top: html.offsetTop ?? 0, left: html.offsetLeft ?? 0 },
    client: { width: html.clientWidth ?? 0, height: html.clientHeight ?? 0, top: html.clientTop ?? 0, left: html.clientLeft ?? 0 },
    scroll: { width: html.scrollWidth ?? 0, height: html.scrollHeight ?? 0, top: html.scrollTop ?? 0, left: html.scrollLeft ?? 0 },
    devicePixelRatio: view.devicePixelRatio
  };
}
function relation(target, reference, selector, kind) {
  return {
    reference: kind,
    referenceSelector: selector,
    deltaCssPx: { x: target.left - reference.left, y: target.top - reference.top },
    edgeGapsCssPx: {
      leftToRight: target.left - reference.right,
      rightToLeft: reference.left - target.right,
      topToBottom: target.top - reference.bottom,
      bottomToTop: reference.top - target.bottom
    }
  };
}
var NO_RELATION = {
  reference: "none",
  referenceSelector: null,
  deltaCssPx: null,
  edgeGapsCssPx: null
};
function extractPosition(element, referenceElement = null, referenceSelector = null) {
  const metrics = extractElementMetrics(element);
  const html = element;
  const offsetParent = html.offsetParent;
  return {
    viewport: metrics.viewportRect,
    document: metrics.documentRect,
    relativeToReference: referenceElement ? relation(metrics.viewportRect, extractElementMetrics(referenceElement).viewportRect, referenceSelector, "element") : NO_RELATION,
    relativeToOffsetParent: offsetParent ? relation(metrics.viewportRect, extractElementMetrics(offsetParent).viewportRect, null, "offset-parent") : NO_RELATION
  };
}
function inspectElementLayout(element, options = {}) {
  return {
    targetSelector: options.targetSelector ?? null,
    ...options.includeCssInfluences === false ? {} : { cssInfluences: collectCssInfluences(element) },
    computedStyle: extractComputedStyle(element, options.computedProperties, options.pseudoElement),
    metrics: extractElementMetrics(element),
    position: extractPosition(element, options.referenceElement, options.referenceSelector ?? null)
  };
}
function inspectSelectorLayout(selector, document2 = globalThis.document, options = {}) {
  const element = document2.querySelector(selector);
  if (!element) throw new Error(`No element matched selector: ${selector}`);
  const referenceElement = options.referenceSelector ? document2.querySelector(options.referenceSelector) : null;
  return inspectElementLayout(element, { ...options, targetSelector: selector, referenceElement });
}

// src/page-tools.ts
var SNAPSHOT_PROPERTIES = [
  "display",
  "position",
  "width",
  "height",
  "margin",
  "padding",
  "gap",
  "color",
  "background-color",
  "box-sizing",
  "min-width",
  "min-height",
  "max-width",
  "max-height",
  "grid-template-columns",
  "grid-template-rows",
  "grid-column",
  "grid-row",
  "flex-flow",
  "flex-grow",
  "flex-shrink",
  "flex-basis",
  "justify-content",
  "align-items",
  "align-content",
  "overflow",
  "transform"
];
var PageToolController = class {
  constructor(document2, onStateChange) {
    this.document = document2;
    this.onStateChange = onStateChange;
    this.overlay = new Overlay(document2);
    document2.addEventListener("mousemove", this.onPointerMove, true);
    document2.addEventListener("mousedown", this.onMouseDown, true);
    document2.addEventListener("mouseup", this.onMouseUp, true);
    document2.addEventListener("click", this.onClick, true);
    document2.defaultView?.addEventListener("keydown", this.onKeyDown, true);
    document2.defaultView?.addEventListener("scroll", this.refreshOverlay, true);
    document2.defaultView?.addEventListener("resize", this.refreshOverlay);
  }
  /** Inspector focus; it may be a normal selection, A, or B. */
  selected = null;
  /** Normal element selection, intentionally independent from A/B comparison state. */
  normalSelection = null;
  anchor = null;
  measureTarget = null;
  rulerStart = null;
  rulerEnd = null;
  rulerSnapEnabled = false;
  verticalGuides = /* @__PURE__ */ new Set();
  horizontalGuides = /* @__PURE__ */ new Set();
  selectedWorkSelectors = /* @__PURE__ */ new Map();
  mode = null;
  activeWorkItem = null;
  pickerCursor = null;
  consumeNextClick = false;
  changes = /* @__PURE__ */ new Map();
  overlay;
  startPicker(mode) {
    this.mode = mode === "select" || mode === "auto-select" ? mode : mode === "measure" ? "measure-anchor" : "ruler";
    if (mode === "measure") {
      this.anchor = null;
      this.measureTarget = null;
    }
    if (mode === "ruler") {
      this.rulerStart = null;
      this.rulerEnd = null;
    }
    this.showPickerCursor();
    this.overlay.clearHover();
    this.refreshOverlay();
    this.notifyStateChange();
  }
  /** Makes a work-list row the current CSS inspector target without altering its saved role. */
  focusWorkItem(id) {
    const element = id === "selection" ? this.normalSelection : id === "anchor" ? this.anchor : id === "target" ? this.measureTarget : null;
    if (id !== "ruler" && !element) throw new Error("\uC120\uD0DD\uD560 \uC791\uC5C5 \uD56D\uBAA9\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.");
    if (element) this.selected = element;
    this.activeWorkItem = id;
    this.refreshOverlay();
    this.notifyStateChange();
  }
  /** Removes just the requested tab-local selection or drawing. Removing A also clears its dependent B. */
  clearWorkItem(id) {
    if (id === "selection") {
      const previous = this.normalSelection;
      this.normalSelection = null;
      if (this.selected === previous) this.selected = this.measureTarget ?? this.anchor;
    } else if (id === "anchor") {
      const previousAnchor = this.anchor;
      const previousTarget = this.measureTarget;
      this.anchor = null;
      this.measureTarget = null;
      if (this.selected === previousAnchor || this.selected === previousTarget) this.selected = this.normalSelection;
    } else if (id === "target") {
      const previous = this.measureTarget;
      this.measureTarget = null;
      if (this.selected === previous) this.selected = this.normalSelection ?? this.anchor;
    } else {
      this.rulerStart = null;
      this.rulerEnd = null;
    }
    if (this.activeWorkItem === id || id === "anchor" && this.activeWorkItem === "target") this.activeWorkItem = this.selected === this.normalSelection && this.normalSelection ? "selection" : null;
    if (id === "anchor") {
      this.selectedWorkSelectors.delete("anchor");
      this.selectedWorkSelectors.delete("target");
    } else if (id !== "ruler") this.selectedWorkSelectors.delete(id);
    this.refreshOverlay();
    this.notifyStateChange();
  }
  /** Selects the display/copy selector for an existing element role without changing the underlying element. */
  setWorkItemSelector(id, selector) {
    const element = id === "selection" ? this.normalSelection : id === "anchor" ? this.anchor : this.measureTarget;
    if (!element) throw new Error("\uC120\uD0DD\uC790\uB97C \uBC14\uAFC0 \uC791\uC5C5 \uD56D\uBAA9\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.");
    if (!selectorCandidatesFor(element).some((candidate) => candidate.selector === selector)) throw new Error("\uC774 \uC694\uC18C\uC5D0 \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uB294 selector\uC785\uB2C8\uB2E4.");
    this.selectedWorkSelectors.set(id, selector);
    this.refreshOverlay();
    this.notifyStateChange();
  }
  /** Selects an element from the DOM-tree panel and treats it as the normal selection. */
  selectTreeNode(selector) {
    let element;
    try {
      element = this.document.querySelector(selector);
    } catch {
      throw new Error("\uC720\uD6A8\uD55C DOM tree selector\uAC00 \uC544\uB2D9\uB2C8\uB2E4.");
    }
    if (!element || this.overlay.contains(element)) throw new Error("\uD604\uC7AC \uD398\uC774\uC9C0\uC5D0\uC11C DOM tree \uC694\uC18C\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
    this.normalSelection = element;
    this.selected = element;
    this.activeWorkItem = "selection";
    this.refreshOverlay();
    this.notifyStateChange();
  }
  setRulerSnap(enabled) {
    this.rulerSnapEnabled = enabled;
    this.notifyStateChange();
  }
  /** Removes only the tab-local guides produced by the most recent completed Ruler. */
  clearRulerGuides() {
    this.verticalGuides.clear();
    this.horizontalGuides.clear();
    this.refreshOverlay();
    this.notifyStateChange();
  }
  applyStyle(property, value, priority) {
    const element = this.requireSelected();
    const normalizedProperty = this.requireValidProperty(property);
    const normalizedPriority = priority?.trim().toLowerCase();
    if (normalizedPriority && normalizedPriority !== "important") throw new Error("priority\uB294 important\uB9CC \uC9C0\uC6D0\uD569\uB2C8\uB2E4.");
    if (!normalizedProperty.startsWith("--") && !this.supports(normalizedProperty, value)) throw new Error(`\uC720\uD6A8\uD55C ${normalizedProperty} CSS \uAC12\uC774 \uC544\uB2D9\uB2C8\uB2E4.`);
    this.capture(element, normalizedProperty);
    element.style.setProperty(normalizedProperty, value, normalizedPriority);
    this.refreshOverlay();
    this.notifyStateChange();
  }
  removeStyle(property) {
    const element = this.requireSelected();
    const normalizedProperty = this.requireValidProperty(property);
    this.capture(element, normalizedProperty);
    element.style.removeProperty(normalizedProperty);
    this.refreshOverlay();
    this.notifyStateChange();
  }
  hideSelected() {
    const element = this.requireSelected();
    this.capture(element, "display");
    element.style.setProperty("display", "none", "important");
    this.refreshOverlay();
    this.notifyStateChange();
  }
  restoreSelected() {
    const element = this.requireSelected();
    this.restoreElement(element);
    this.refreshOverlay();
    this.notifyStateChange();
  }
  restoreAll() {
    for (const element of this.changes.keys()) this.restoreElement(element);
    this.refreshOverlay();
    this.notifyStateChange();
  }
  state() {
    const referenceSelector = this.anchor ? selectorFor(this.anchor) : null;
    const inspection = this.selected ? inspectElementLayout(this.selected, {
      targetSelector: selectorFor(this.selected),
      referenceElement: this.anchor,
      referenceSelector,
      computedProperties: SNAPSHOT_PROPERTIES
    }) : null;
    const cssInspector = this.selected ? inspectCssDeclarations(this.selected) : null;
    const measurement = this.anchor && this.measureTarget ? {
      anchor: summarize(this.anchor),
      target: summarize(this.measureTarget),
      relative: inspectElementLayout(this.measureTarget, {
        targetSelector: selectorFor(this.measureTarget),
        referenceElement: this.anchor,
        referenceSelector,
        includeCssInfluences: false,
        computedProperties: []
      }).position.relativeToReference
    } : null;
    const ruler = this.rulerStart && this.rulerEnd ? measureRuler(this.rulerStart, this.rulerEnd) : null;
    return {
      environment: environmentFor(this.document),
      pickerMode: this.mode === "select" ? "select" : this.mode === "auto-select" ? "auto-select" : this.mode === "ruler" ? "ruler" : this.mode ? "measure" : null,
      selected: this.selected ? summarize(this.selected) : null,
      workItems: this.workItems(ruler),
      inspection,
      cssInspector,
      measurement,
      ruler,
      rulerSnapEnabled: this.rulerSnapEnabled,
      guides: { vertical: [...this.verticalGuides].sort((a, b) => a - b), horizontal: [...this.horizontalGuides].sort((a, b) => a - b) },
      changedElementCount: this.changes.size
    };
  }
  onPointerMove = (event) => {
    if (!this.mode) return;
    if (this.mode === "ruler") {
      if (!this.rulerStart) return;
      this.rulerEnd = pointFrom(event, this.rulerSnapEnabled);
      this.overlay.showRuler(this.rulerStart, this.rulerEnd);
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    const element = this.elementFromEvent(event);
    if (!element) return;
    if (this.mode === "auto-select") {
      if (element !== this.normalSelection || element !== this.selected) {
        this.normalSelection = element;
        this.selected = element;
        this.activeWorkItem = "selection";
        this.refreshOverlay();
        this.notifyStateChange();
      }
      this.overlay.showHover(element, "#0f766e");
      return;
    }
    this.overlay.showHover(element, this.mode === "select" ? "#2563eb" : "#f59e0b");
  };
  onMouseDown = (event) => {
    if (this.mode !== "ruler" || event.button !== 0) return;
    this.rulerStart = pointFrom(event, this.rulerSnapEnabled);
    this.rulerEnd = this.rulerStart;
    this.overlay.showRuler(this.rulerStart, this.rulerEnd);
    event.preventDefault();
    event.stopImmediatePropagation();
  };
  onMouseUp = (event) => {
    if (this.mode !== "ruler" || event.button !== 0 || !this.rulerStart) return;
    this.rulerEnd = pointFrom(event, this.rulerSnapEnabled);
    this.replaceRulerGuides();
    this.mode = null;
    this.clearPickerCursor();
    this.consumeNextClick = true;
    this.refreshOverlay();
    this.notifyStateChange();
    event.preventDefault();
    event.stopImmediatePropagation();
  };
  onClick = (event) => {
    if (this.consumeNextClick) {
      this.consumeNextClick = false;
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    if (!this.mode || event.button !== 0) return;
    const element = this.elementFromEvent(event);
    if (!element) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (this.mode === "auto-select") return;
    if (this.mode === "select") {
      this.normalSelection = element;
      this.selected = element;
      this.activeWorkItem = "selection";
      this.mode = null;
    } else if (this.mode === "measure-anchor") {
      this.anchor = element;
      this.measureTarget = null;
      this.selected = element;
      this.activeWorkItem = "anchor";
      this.mode = "measure-target";
    } else {
      this.measureTarget = element;
      this.selected = element;
      this.activeWorkItem = "target";
      this.mode = null;
    }
    if (!this.mode) this.clearPickerCursor();
    this.overlay.clearHover();
    this.refreshOverlay();
    this.notifyStateChange();
  };
  onKeyDown = (event) => {
    if (event.key === "Escape" && this.mode) {
      this.mode = null;
      this.clearPickerCursor();
      this.overlay.clearHover();
      this.notifyStateChange();
      return;
    }
    if (this.mode !== "auto-select" || event.key !== "Delete" && event.key !== "Backspace" || isEditable(event.target)) return;
    if (!this.normalSelection) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    this.selected = this.normalSelection;
    this.hideSelected();
  };
  refreshOverlay = () => {
    this.overlay.showSelected(this.normalSelection);
    this.overlay.showMeasurement(
      this.anchor,
      this.measureTarget,
      this.selectorForWorkItem("anchor", this.anchor),
      this.selectorForWorkItem("target", this.measureTarget)
    );
    this.overlay.showRuler(this.rulerStart, this.rulerEnd);
    this.overlay.showGuides(this.verticalGuides, this.horizontalGuides);
  };
  /** A completed Ruler owns exactly its four edge guides; the next completed Ruler replaces them. */
  replaceRulerGuides() {
    if (!this.rulerStart || !this.rulerEnd) return;
    const guides = rulerGuides(measureRuler(this.rulerStart, this.rulerEnd));
    this.verticalGuides.clear();
    this.horizontalGuides.clear();
    for (const value of guides.vertical) this.verticalGuides.add(value);
    for (const value of guides.horizontal) this.horizontalGuides.add(value);
  }
  elementFromEvent(event) {
    const target = event.target;
    if (!(target instanceof Element) || this.overlay.contains(target)) return null;
    return target;
  }
  requireSelected() {
    if (!this.selected) throw new Error("\uBA3C\uC800 \uD398\uC774\uC9C0\uC5D0\uC11C \uC694\uC18C\uB97C \uC120\uD0DD\uD558\uC138\uC694.");
    return this.selected;
  }
  workItems(ruler) {
    const items = [];
    if (this.normalSelection?.isConnected) items.push(elementWorkItem("selection", "\uC77C\uBC18 \uC120\uD0DD", this.normalSelection, this.activeWorkItem, this.selectedWorkSelectors));
    if (this.anchor?.isConnected) items.push(elementWorkItem("anchor", "\uBE44\uAD50 A", this.anchor, this.activeWorkItem, this.selectedWorkSelectors));
    if (this.measureTarget?.isConnected) items.push(elementWorkItem("target", "\uBE44\uAD50 B", this.measureTarget, this.activeWorkItem, this.selectedWorkSelectors));
    if (ruler) items.push({ id: "ruler", role: "Ruler", label: "Ruler box", detail: `${ruler.width} \xD7 ${ruler.height}px \xB7 ${ruler.distance}px`, active: this.activeWorkItem === "ruler", selectorCandidates: [], selectedSelector: null });
    return items;
  }
  selectorForWorkItem(id, element) {
    if (!element?.isConnected) return null;
    const candidates = selectorCandidatesFor(element);
    const chosen = this.selectedWorkSelectors.get(id);
    return candidates.some((candidate) => candidate.selector === chosen) ? chosen : candidates[0]?.selector ?? selectorFor(element);
  }
  showPickerCursor() {
    const style = this.document.documentElement.style;
    if (!this.pickerCursor) {
      const value = style.getPropertyValue("cursor");
      this.pickerCursor = { value, priority: style.getPropertyPriority("cursor"), wasPresent: value !== "" };
    }
    style.setProperty("cursor", "crosshair", "important");
  }
  clearPickerCursor() {
    if (!this.pickerCursor) return;
    const style = this.document.documentElement.style;
    if (this.pickerCursor.wasPresent) style.setProperty("cursor", this.pickerCursor.value, this.pickerCursor.priority);
    else style.removeProperty("cursor");
    this.pickerCursor = null;
  }
  requireValidProperty(property) {
    const normalizedProperty = property.trim();
    if (!normalizedProperty || /[;:{}]/.test(normalizedProperty)) throw new Error("\uC720\uD6A8\uD55C CSS \uC18D\uC131\uBA85\uC744 \uC785\uB825\uD558\uC138\uC694.");
    if (normalizedProperty.startsWith("--")) {
      if (!/^--[-_a-zA-Z0-9]+$/.test(normalizedProperty)) throw new Error("\uC720\uD6A8\uD55C CSS custom property \uC774\uB984\uC744 \uC785\uB825\uD558\uC138\uC694.");
      return normalizedProperty;
    }
    if (!this.supports(normalizedProperty, "initial")) throw new Error("\uC720\uD6A8\uD55C CSS \uC18D\uC131\uBA85\uC744 \uC785\uB825\uD558\uC138\uC694.");
    return normalizedProperty;
  }
  supports(property, value) {
    return this.document.defaultView?.CSS.supports(property, value) ?? false;
  }
  capture(element, property) {
    let elementChanges = this.changes.get(element);
    if (!elementChanges) {
      elementChanges = /* @__PURE__ */ new Map();
      this.changes.set(element, elementChanges);
    }
    if (elementChanges.has(property)) return;
    const style = element.style;
    const value = style.getPropertyValue(property);
    elementChanges.set(property, { value, priority: style.getPropertyPriority(property), wasPresent: value !== "" });
  }
  restoreElement(element) {
    const elementChanges = this.changes.get(element);
    if (!elementChanges) return;
    const style = element.style;
    for (const [property, original] of elementChanges) {
      if (original.wasPresent) style.setProperty(property, original.value, original.priority);
      else style.removeProperty(property);
    }
    this.changes.delete(element);
  }
  notifyStateChange() {
    this.onStateChange?.(this.state());
  }
};
var Overlay = class {
  root;
  hover = this.createBox();
  selected = this.createBox();
  anchor = this.createBox();
  target = this.createBox();
  measureLabel;
  dimensions;
  ruler;
  rulerLabel;
  guides;
  labelOffsets = /* @__PURE__ */ new Map();
  drag = null;
  constructor(document2) {
    this.root = document2.createElement("div");
    this.root.setAttribute("data-browser-layout-inspector-ui", "true");
    Object.assign(this.root.style, { position: "fixed", inset: "0", zIndex: "2147483647", pointerEvents: "none" });
    this.measureLabel = document2.createElement("div");
    this.measureLabel.setAttribute("data-browser-layout-inspector-measurement-summary", "true");
    Object.assign(this.measureLabel.style, {
      position: "fixed",
      display: "none",
      maxWidth: "340px",
      padding: "5px 7px",
      borderRadius: "4px",
      background: "#172033",
      color: "#fff",
      cursor: "copy",
      pointerEvents: "auto",
      font: "12px/1.35 ui-monospace, SFMono-Regular, monospace",
      boxShadow: "0 2px 8px rgb(0 0 0 / 0.25)"
    });
    this.enableMeasurementLabel(this.measureLabel, "comparison-summary");
    this.dimensions = document2.createElement("div");
    Object.assign(this.dimensions.style, { position: "fixed", inset: "0", pointerEvents: "none" });
    this.ruler = document2.createElement("div");
    Object.assign(this.ruler.style, { position: "fixed", display: "none", boxSizing: "border-box", border: "1px dashed #7c3aed", background: "rgb(124 58 237 / 0.08)" });
    this.rulerLabel = document2.createElement("div");
    Object.assign(this.rulerLabel.style, {
      position: "absolute",
      left: "-1px",
      top: "-23px",
      padding: "4px 6px",
      borderRadius: "4px",
      whiteSpace: "nowrap",
      background: "#6d28d9",
      color: "#fff",
      font: "12px/1.25 ui-monospace, SFMono-Regular, monospace",
      boxShadow: "0 2px 8px rgb(0 0 0 / 0.25)"
    });
    this.ruler.append(this.rulerLabel);
    this.guides = document2.createElement("div");
    Object.assign(this.guides.style, { position: "fixed", inset: "0", pointerEvents: "none" });
    this.root.append(this.guides, this.hover, this.selected, this.anchor, this.target, this.dimensions, this.measureLabel, this.ruler);
    document2.documentElement.append(this.root);
    document2.addEventListener("pointermove", this.onLabelPointerMove, true);
    document2.addEventListener("pointerup", this.onLabelPointerUp, true);
    document2.addEventListener("pointercancel", this.onLabelPointerCancel, true);
  }
  contains(element) {
    return this.root.contains(element);
  }
  clearHover() {
    this.hover.style.display = "none";
  }
  showHover(element, color) {
    this.showBox(this.hover, element, color, "hover");
  }
  showSelected(element) {
    if (!element || !element.isConnected) return this.hide(this.selected);
    this.showBox(this.selected, element, "#2563eb", `\uC120\uD0DD \xB7 ${selectorFor(element)}`);
  }
  showMeasurement(anchor, target, anchorSelector, targetSelector) {
    if (!anchor || !anchor.isConnected) this.hide(this.anchor);
    else this.showBox(this.anchor, anchor, "#f59e0b", `\uAE30\uC900 \xB7 ${anchorSelector ?? selectorFor(anchor)}`);
    if (!target || !target.isConnected) {
      this.hide(this.target);
      this.measureLabel.style.display = "none";
      this.dimensions.replaceChildren();
      return;
    }
    this.showBox(this.target, target, "#ef4444", `\uB300\uC0C1 \xB7 ${targetSelector ?? selectorFor(target)}`);
    if (!anchor || !anchor.isConnected) {
      this.dimensions.replaceChildren();
      return;
    }
    const a = anchor.getBoundingClientRect();
    const b = target.getBoundingClientRect();
    const comparison = measureElementComparison(a, b);
    this.measureLabel.textContent = `${anchorSelector ?? selectorFor(anchor)} \u2192 ${targetSelector ?? selectorFor(target)}  \u0394x ${comparison.deltaCssPx.x}px \xB7 \u0394y ${comparison.deltaCssPx.y}px  |  right\u2192left ${comparison.directionalEdgeGapsCssPx.referenceRightToTargetLeft}px \xB7 bottom\u2192top ${comparison.directionalEdgeGapsCssPx.referenceBottomToTargetTop}px`;
    this.measureLabel.dataset.copyValue = this.measureLabel.textContent;
    this.applyLabelOffset(this.measureLabel, "comparison-summary");
    Object.assign(this.measureLabel.style, { display: "block", left: `${Math.max(8, Math.min(b.left, window.innerWidth - 348))}px`, top: `${Math.max(8, Math.min(b.bottom + 8, window.innerHeight - 52))}px` });
    this.showCornerDimensions(a, b, comparison);
  }
  showRuler(start, end) {
    if (!start || !end) {
      this.ruler.style.display = "none";
      return;
    }
    const measurement = measureRuler(start, end);
    Object.assign(this.ruler.style, {
      display: "block",
      left: `${Math.min(start.x, end.x)}px`,
      top: `${Math.min(start.y, end.y)}px`,
      width: `${measurement.width}px`,
      height: `${measurement.height}px`
    });
    this.rulerLabel.textContent = `Ruler \xB7 W ${measurement.width}px \xB7 H ${measurement.height}px \xB7 \u2197 ${measurement.distance}px \xB7 \u2220 ${measurement.angle}\xB0`;
  }
  showGuides(vertical, horizontal) {
    this.guides.replaceChildren();
    for (const x of vertical) this.guides.append(this.createGuide("vertical", x));
    for (const y of horizontal) this.guides.append(this.createGuide("horizontal", y));
  }
  createBox() {
    const box = this.root?.ownerDocument.createElement("div") ?? document.createElement("div");
    Object.assign(box.style, {
      position: "fixed",
      display: "none",
      boxSizing: "border-box",
      border: "2px solid",
      background: "rgb(37 99 235 / 0.08)",
      color: "#fff",
      font: "11px/1.25 ui-monospace, SFMono-Regular, monospace"
    });
    const label = box.ownerDocument.createElement("span");
    label.dataset.role = "label";
    Object.assign(label.style, { position: "absolute", left: "-2px", top: "-20px", maxWidth: "330px", padding: "2px 4px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", background: "#2563eb" });
    box.append(label);
    return box;
  }
  createGuide(direction, value) {
    const guide = this.guides.ownerDocument.createElement("div");
    guide.setAttribute("data-browser-layout-inspector-guide", direction);
    Object.assign(guide.style, direction === "vertical" ? { position: "fixed", left: `${value}px`, top: "0", bottom: "0", borderLeft: "1px dashed #d946ef" } : { position: "fixed", left: "0", right: "0", top: `${value}px`, borderTop: "1px dashed #d946ef" });
    return guide;
  }
  /** Draws four corresponding-corner measurements, retaining signs for overlap and containment. */
  showCornerDimensions(a, b, comparison = measureElementComparison(a, b)) {
    const top = Math.max(26, Math.min(a.top, b.top) - 26);
    const bottom = Math.min(window.innerHeight - 18, Math.max(a.bottom, b.bottom) + 26);
    const left = Math.max(30, Math.min(a.left, b.left) - 30);
    const right = Math.min(window.innerWidth - 18, Math.max(a.right, b.right) + 30);
    const dimensions = [
      this.nonZeroDimension(comparison.cornerDeltasCssPx.left, () => this.createHorizontalDimension("left", a.left, b.left, top, "A.left \u2192 B.left", comparison.cornerDeltasCssPx.left, "above")),
      this.nonZeroDimension(comparison.cornerDeltasCssPx.right, () => this.createHorizontalDimension("right", a.right, b.right, bottom, "A.right \u2192 B.right", comparison.cornerDeltasCssPx.right, "below")),
      this.nonZeroDimension(comparison.cornerDeltasCssPx.top, () => this.createVerticalDimension("top", a.top, b.top, left, "A.top \u2192 B.top", comparison.cornerDeltasCssPx.top, "right")),
      this.nonZeroDimension(comparison.cornerDeltasCssPx.bottom, () => this.createVerticalDimension("bottom", a.bottom, b.bottom, right, "A.bottom \u2192 B.bottom", comparison.cornerDeltasCssPx.bottom, "left")),
      ...this.gapDimensions(comparison.gaps)
    ].filter((dimension) => dimension !== null);
    this.dimensions.replaceChildren(...dimensions);
  }
  nonZeroDimension(value, create) {
    return round2(value) === 0 ? null : create();
  }
  /** Renders only positive, projection-overlapping gaps calculated by the DOM-free measurement core. */
  gapDimensions(gaps) {
    return gaps.map((gap) => {
      const title = `${gap.from.box === "reference" ? "A" : "B"}.${gap.from.edge} \u2192 ${gap.to.box === "reference" ? "A" : "B"}.${gap.to.edge} gap`;
      return gap.axis === "horizontal" ? this.createHorizontalDimension("gap-horizontal", gap.start, gap.end, gap.crossAxisCenter, title, gap.cssPx, "above", false) : this.createVerticalDimension("gap-vertical", gap.start, gap.end, gap.crossAxisCenter, title, gap.cssPx, "right", false);
    });
  }
  createHorizontalDimension(id, start, end, y, title, value, labelPosition, signed = true) {
    const line = this.dimensions.ownerDocument.createElement("div");
    const left = Math.min(start, end);
    Object.assign(line.style, {
      position: "fixed",
      left: `${left}px`,
      top: `${y}px`,
      width: `${Math.max(2, Math.abs(end - start))}px`,
      height: "2px",
      borderTop: "2px solid #0f766e",
      background: "rgb(45 212 191 / 0.3)",
      boxShadow: "0 0 3px rgb(20 184 166 / 0.75)"
    });
    line.setAttribute("data-browser-layout-inspector-dimension", id);
    if (id.startsWith("gap-")) line.setAttribute("data-browser-layout-inspector-gap", id.slice(4));
    line.append(this.dimensionTick("vertical", start - left), this.dimensionTick("vertical", end - left), this.dimensionLabel(id, title, value, labelPosition, signed));
    return line;
  }
  createVerticalDimension(id, start, end, x, title, value, labelPosition, signed = true) {
    const line = this.dimensions.ownerDocument.createElement("div");
    const top = Math.min(start, end);
    Object.assign(line.style, {
      position: "fixed",
      left: `${x}px`,
      top: `${top}px`,
      width: "2px",
      height: `${Math.max(2, Math.abs(end - start))}px`,
      borderLeft: "2px solid #0f766e",
      background: "rgb(45 212 191 / 0.3)",
      boxShadow: "0 0 3px rgb(20 184 166 / 0.75)"
    });
    line.setAttribute("data-browser-layout-inspector-dimension", id);
    if (id.startsWith("gap-")) line.setAttribute("data-browser-layout-inspector-gap", id.slice(4));
    line.append(this.dimensionTick("horizontal", start - top), this.dimensionTick("horizontal", end - top), this.dimensionLabel(id, title, value, labelPosition, signed));
    return line;
  }
  dimensionTick(direction, offset) {
    const tick = this.dimensions.ownerDocument.createElement("div");
    Object.assign(tick.style, direction === "vertical" ? { position: "absolute", left: `${offset}px`, top: "-6px", height: "12px", borderLeft: "2px solid #0f766e", boxShadow: "0 0 2px rgb(20 184 166 / 0.75)" } : { position: "absolute", left: "-6px", top: `${offset}px`, width: "12px", borderTop: "2px solid #0f766e", boxShadow: "0 0 2px rgb(20 184 166 / 0.75)" });
    return tick;
  }
  dimensionLabel(key, title, value, position, signed) {
    const label = this.dimensions.ownerDocument.createElement("span");
    label.textContent = `${title} ${signed ? signedPixels(value) : pixels(value)}`;
    label.dataset.copyValue = label.textContent;
    Object.assign(label.style, {
      position: "absolute",
      padding: "2px 4px",
      borderRadius: "3px",
      background: "#0f766e",
      color: "#fff",
      cursor: "grab",
      pointerEvents: "auto",
      whiteSpace: "nowrap",
      font: "11px/1.25 ui-monospace, SFMono-Regular, monospace",
      boxShadow: "0 1px 4px rgb(0 0 0 / 0.2)",
      transition: "background-color 120ms ease, box-shadow 120ms ease, outline-color 120ms ease"
    });
    if (position === "above") Object.assign(label.style, { left: "50%", top: "-5px", transform: "translate(-50%, -100%)" });
    else if (position === "below") Object.assign(label.style, { left: "50%", top: "5px", transform: "translateX(-50%)" });
    else if (position === "left") Object.assign(label.style, { left: "-5px", top: "50%", transform: "translate(-100%, -50%)" });
    else Object.assign(label.style, { left: "5px", top: "50%", transform: "translateY(-50%)" });
    this.enableMeasurementLabel(label, key);
    return label;
  }
  enableMeasurementLabel(label, key) {
    label.dataset.browserLayoutInspectorLabel = key;
    label.title = "\uD074\uB9AD: \uCE21\uC815\uAC12 \uBCF5\uC0AC \xB7 \uB4DC\uB798\uADF8: \uB77C\uBCA8 \uC774\uB3D9";
    label.addEventListener("pointerenter", () => {
      if (this.drag?.label === label) return;
      Object.assign(label.style, { background: "#115e59", boxShadow: "0 3px 10px rgb(15 118 110 / 0.55)", outline: "2px solid rgb(94 234 212 / 0.95)", outlineOffset: "2px" });
      this.emphasizeDimension(this.dimensionLineFor(label), true);
    });
    label.addEventListener("pointerleave", () => {
      if (this.drag?.label === label) return;
      Object.assign(label.style, { background: "#0f766e", boxShadow: "0 1px 4px rgb(0 0 0 / 0.2)", outline: "none" });
      this.emphasizeDimension(this.dimensionLineFor(label), false);
    });
    label.addEventListener("pointerdown", (event) => this.startLabelPointer(event, label, key));
    this.applyLabelOffset(label, key);
  }
  startLabelPointer(event, label, key) {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    const initial = this.labelOffsets.get(key) ?? { x: 0, y: 0 };
    const line = this.dimensionLineFor(label);
    this.drag = { label, line, key, start: { x: event.clientX, y: event.clientY }, initial, moved: false };
    label.setPointerCapture?.(event.pointerId);
    Object.assign(label.style, { cursor: "grabbing", background: "#134e4a", outline: "2px solid rgb(94 234 212 / 0.95)", outlineOffset: "2px" });
    this.emphasizeDimension(line, true);
  }
  onLabelPointerMove = (event) => {
    const drag = this.drag;
    if (!drag) return;
    const offset = { x: drag.initial.x + event.clientX - drag.start.x, y: drag.initial.y + event.clientY - drag.start.y };
    if (Math.abs(offset.x - drag.initial.x) > 2 || Math.abs(offset.y - drag.initial.y) > 2) drag.moved = true;
    this.labelOffsets.set(drag.key, offset);
    this.applyLabelOffset(drag.label, drag.key);
    event.preventDefault();
    event.stopPropagation();
  };
  onLabelPointerUp = (event) => {
    const drag = this.drag;
    if (!drag) return;
    this.drag = null;
    drag.label.releasePointerCapture?.(event.pointerId);
    Object.assign(drag.label.style, { cursor: "grab", background: "#0f766e", outline: "none", boxShadow: "0 1px 4px rgb(0 0 0 / 0.2)" });
    this.emphasizeDimension(drag.line, false);
    if (!drag.moved) this.copyLabel(drag.label);
    event.preventDefault();
    event.stopPropagation();
  };
  onLabelPointerCancel = () => {
    const drag = this.drag;
    if (!drag) return;
    this.drag = null;
    Object.assign(drag.label.style, { cursor: "grab", background: "#0f766e", outline: "none", boxShadow: "0 1px 4px rgb(0 0 0 / 0.2)" });
    this.emphasizeDimension(drag.line, false);
  };
  applyLabelOffset(label, key) {
    const offset = this.labelOffsets.get(key) ?? { x: 0, y: 0 };
    const base = label.dataset.baseTransform ?? label.style.transform;
    label.dataset.baseTransform = base;
    label.style.transform = `${base} translate(${offset.x}px, ${offset.y}px)`;
  }
  dimensionLineFor(label) {
    return label.closest("[data-browser-layout-inspector-dimension]");
  }
  emphasizeDimension(line, active) {
    if (!line) return;
    line.toggleAttribute("data-browser-layout-inspector-dimension-active", active);
    Object.assign(line.style, active ? { borderColor: "#5eead4", background: "rgb(94 234 212 / 0.7)", filter: "drop-shadow(0 0 5px rgb(45 212 191 / 0.95))", zIndex: "1" } : { borderColor: "#0f766e", background: "rgb(45 212 191 / 0.3)", filter: "", zIndex: "" });
    for (const child of line.children) {
      if (!(child instanceof HTMLElement) || child.dataset.browserLayoutInspectorLabel) continue;
      child.style.borderColor = active ? "#5eead4" : "#0f766e";
      child.style.filter = active ? "drop-shadow(0 0 2px rgb(45 212 191 / 0.95))" : "";
    }
  }
  copyLabel(label) {
    const value = label.dataset.copyValue ?? label.textContent ?? "";
    if (!value) return;
    void copyToClipboard(this.root.ownerDocument, value).then(() => {
      const original = label.textContent;
      label.textContent = "\uBCF5\uC0AC\uB428";
      window.setTimeout(() => {
        label.textContent = original;
      }, 900);
    }).catch(() => {
      const original = label.textContent;
      label.textContent = "\uBCF5\uC0AC \uC2E4\uD328";
      window.setTimeout(() => {
        label.textContent = original;
      }, 1200);
    });
  }
  showBox(box, element, color, label) {
    const rect = element.getBoundingClientRect();
    const labelElement = box.querySelector('[data-role="label"]');
    Object.assign(box.style, { display: "block", left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px`, borderColor: color, backgroundColor: `${color}16` });
    labelElement.style.background = color;
    labelElement.textContent = `${label} \xB7 ${round2(rect.width)} \xD7 ${round2(rect.height)}`;
  }
  hide(element) {
    element.style.display = "none";
  }
};
function summarize(element) {
  const text = element.textContent?.trim().replace(/\s+/g, " ") ?? "";
  return { selector: selectorFor(element), tagName: element.tagName.toLowerCase(), text: text ? text.slice(0, 80) : null };
}
function elementWorkItem(id, role, element, activeWorkItem, selectedWorkSelectors) {
  const selectorCandidates = selectorCandidatesFor(element);
  const selectedSelector = selectedWorkSelectors.get(id) && selectorCandidates.some((candidate) => candidate.selector === selectedWorkSelectors.get(id)) ? selectedWorkSelectors.get(id) : selectorCandidates[0]?.selector ?? selectorFor(element);
  const chosen = selectorCandidates.find((candidate) => candidate.selector === selectedSelector);
  return {
    id,
    role,
    label: selectedSelector,
    detail: selectorCandidateDescription(chosen),
    active: activeWorkItem === id,
    selectorCandidates,
    selectedSelector
  };
}
function selectorCandidatesFor(element) {
  const seen = /* @__PURE__ */ new Set();
  const candidates = [];
  const add = (selector, source) => {
    if (!selector || seen.has(selector)) return;
    seen.add(selector);
    candidates.push({ selector, source, unique: matchesOnly(element, selector) });
  };
  for (const declaration of inspectCssDeclarations(element).sourceDeclarations) {
    if (declaration.source === "author" && declaration.selector) add(declaration.selector, "matched-css");
  }
  const id = element.getAttribute("id");
  if (id) add(`#${cssEscape(id)}`, "unique");
  for (const attribute of ["data-testid", "data-qa-id", "data-measure-id"]) {
    const value = element.getAttribute(attribute);
    if (value) add(`[${attribute}="${cssStringEscape(value)}"]`, "unique");
  }
  add(selectorFor(element), "fallback");
  return candidates.sort((a, b) => selectorCandidateRank(a) - selectorCandidateRank(b) || a.selector.localeCompare(b.selector));
}
function selectorCandidateRank(candidate) {
  if (candidate.source === "matched-css" && candidate.unique) return 0;
  if (candidate.source === "unique" && candidate.unique) return 1;
  if (candidate.source === "matched-css") return 2;
  if (candidate.unique) return 3;
  return 4;
}
function matchesOnly(element, selector) {
  try {
    const matches = element.ownerDocument.querySelectorAll(selector);
    return matches.length === 1 && matches[0] === element;
  } catch {
    return false;
  }
}
function selectorCandidateDescription(candidate) {
  if (!candidate) return "\uAD6C\uC870 selector";
  if (candidate.source === "matched-css") return candidate.unique ? "\uB9E4\uCE6D CSS \xB7 \uACE0\uC720" : "\uB9E4\uCE6D CSS";
  if (candidate.source === "unique") return "\uACE0\uC720 \uC2DD\uBCC4\uC790";
  return candidate.unique ? "\uAD6C\uC870 selector \xB7 \uACE0\uC720" : "\uAD6C\uC870 selector";
}
function isEditable(target) {
  if (!(target instanceof Element)) return false;
  return target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement || target instanceof HTMLElement && target.isContentEditable;
}
function environmentFor(document2) {
  const view = document2.defaultView;
  if (!view) throw new Error("page measurement requires a browsing context");
  const viewport = view.visualViewport;
  return {
    url: document2.location.href,
    viewportCssPx: { width: view.innerWidth, height: view.innerHeight },
    scrollCssPx: { x: view.scrollX, y: view.scrollY },
    devicePixelRatio: view.devicePixelRatio,
    visualViewport: viewport ? { width: viewport.width, height: viewport.height, scale: viewport.scale } : null
  };
}
function selectorFor(element) {
  const id = element.getAttribute("id");
  if (id) return `#${cssEscape(id)}`;
  for (const attribute of ["data-testid", "data-qa-id", "data-measure-id"]) {
    const value = element.getAttribute(attribute);
    if (value) return `[${attribute}="${cssStringEscape(value)}"]`;
  }
  const segments = [];
  let current = element;
  while (current && current !== current.ownerDocument.documentElement && segments.length < 4) {
    const name = current.tagName.toLowerCase();
    const siblings = current.parentElement ? [...current.parentElement.children].filter((sibling) => sibling.tagName === current.tagName) : [];
    const index = siblings.indexOf(current) + 1;
    segments.unshift(`${name}:nth-of-type(${Math.max(index, 1)})`);
    current = current.parentElement;
  }
  return segments.join(" > ") || element.tagName.toLowerCase();
}
function cssEscape(value) {
  const escape = globalThis.CSS?.escape;
  return escape ? escape(value) : value.replace(/[^a-zA-Z0-9_-]/g, "\\$&");
}
function cssStringEscape(value) {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}
function round2(value) {
  return Math.round(value * 100) / 100;
}
function signedPixels(value) {
  const rounded = round2(value);
  return `${rounded >= 0 ? "+" : ""}${rounded}px`;
}
function pixels(value) {
  return `${round2(Math.abs(value))}px`;
}
async function copyToClipboard(document2, value) {
  const clipboard = document2.defaultView?.navigator.clipboard;
  if (clipboard?.writeText) {
    try {
      await clipboard.writeText(value);
      return;
    } catch {
    }
  }
  const textarea = document2.createElement("textarea");
  textarea.value = value;
  textarea.setAttribute("aria-hidden", "true");
  Object.assign(textarea.style, { position: "fixed", opacity: "0", pointerEvents: "none" });
  document2.body.append(textarea);
  textarea.select();
  const copied = document2.execCommand("copy");
  textarea.remove();
  if (!copied) throw new Error("clipboard write failed");
}
function pointFrom(event, snapToGrid = false) {
  const point = { x: round2(event.clientX), y: round2(event.clientY) };
  return snapToGrid ? { x: snap(point.x), y: snap(point.y) } : point;
}
function snap(value) {
  return Math.round(value / 8) * 8;
}

// src/page-overview.ts
function collectPageDomTree(document2, maxDepth = 5, maxNodes = 240) {
  const root = document2.body;
  if (!root) return null;
  let visited = 0;
  const visit = (element, depth) => {
    visited += 1;
    const pageChildren = [...element.children].filter((child) => !child.hasAttribute("data-browser-layout-inspector-ui"));
    const canDescend = depth < maxDepth && visited < maxNodes;
    const children = canDescend ? pageChildren.map((child) => visit(child, depth + 1)) : [];
    return {
      selector: selectorFor2(element),
      label: nodeLabel(element),
      childCount: pageChildren.length,
      children,
      truncated: pageChildren.length > children.length
    };
  };
  return visit(root, 0);
}
function extractPageStyles(document2) {
  const sections = [];
  const inaccessibleStylesheets = [];
  let accessibleStylesheetCount = 0;
  [...document2.styleSheets].forEach((sheet, index) => {
    const label = sheet.href ?? `<style #${index + 1}>`;
    try {
      const rules = [...sheet.cssRules].map((rule) => rule.cssText).join("\n\n");
      accessibleStylesheetCount += 1;
      sections.push(`/* Source: ${safeComment(label)} */
${rules}`);
    } catch {
      inaccessibleStylesheets.push(label);
    }
  });
  if (inaccessibleStylesheets.length > 0) sections.push(`/* CSSOM unavailable: ${inaccessibleStylesheets.map(safeComment).join(", ")} */`);
  return { css: sections.join("\n\n") || "/* \uC77D\uC744 \uC218 \uC788\uB294 author stylesheet\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. */", accessibleStylesheetCount, inaccessibleStylesheets };
}
function selectorFor2(element) {
  if (element === element.ownerDocument.body) return "body";
  const id = element.getAttribute("id");
  if (id) return `#${cssEscape2(id)}`;
  for (const attribute of ["data-testid", "data-qa-id", "data-measure-id"]) {
    const value = element.getAttribute(attribute);
    if (value) return `[${attribute}="${cssStringEscape2(value)}"]`;
  }
  const segments = [];
  let current = element;
  while (current && current !== current.ownerDocument.documentElement && segments.length < 4) {
    const name = current.tagName.toLowerCase();
    const siblings = current.parentElement ? [...current.parentElement.children].filter((sibling) => sibling.tagName === current.tagName) : [];
    segments.unshift(`${name}:nth-of-type(${Math.max(siblings.indexOf(current) + 1, 1)})`);
    current = current.parentElement;
  }
  return segments.join(" > ") || element.tagName.toLowerCase();
}
function nodeLabel(element) {
  const tag = element.tagName.toLowerCase();
  const id = element.id ? `#${element.id}` : "";
  const classes = [...element.classList].slice(0, 2).map((name) => `.${name}`).join("");
  return `${tag}${id}${classes}`;
}
function cssEscape2(value) {
  return globalThis.CSS?.escape ? globalThis.CSS.escape(value) : value.replace(/[^a-zA-Z0-9_-]/g, "\\$&");
}
function cssStringEscape2(value) {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}
function safeComment(value) {
  return value.replaceAll("*/", "* /").replaceAll("\n", " ");
}

// src/protocol.ts
function isInspectSelectorRequest(message) {
  return typeof message === "object" && message !== null && message.type === "browser-layout-inspector.inspect-selector" && typeof message.selector === "string";
}
function isPageToolRequest(message) {
  if (typeof message !== "object" || message === null) return false;
  const value = message;
  switch (value.type) {
    case "browser-layout-inspector.start-picker":
      return value.mode === "select" || value.mode === "auto-select" || value.mode === "measure" || value.mode === "ruler";
    case "browser-layout-inspector.focus-work-item":
    case "browser-layout-inspector.clear-work-item":
      return value.id === "selection" || value.id === "anchor" || value.id === "target" || value.id === "ruler";
    case "browser-layout-inspector.set-work-item-selector":
      return (value.id === "selection" || value.id === "anchor" || value.id === "target") && typeof value.selector === "string";
    case "browser-layout-inspector.select-tree-node":
      return typeof value.selector === "string";
    case "browser-layout-inspector.get-state":
    case "browser-layout-inspector.clear-ruler-guides":
    case "browser-layout-inspector.hide-selected":
    case "browser-layout-inspector.restore-selected":
    case "browser-layout-inspector.restore-all":
      return true;
    case "browser-layout-inspector.set-ruler-snap":
      return typeof value.enabled === "boolean";
    case "browser-layout-inspector.apply-style":
      return typeof value.property === "string" && typeof value.value === "string" && (value.priority === void 0 || typeof value.priority === "string");
    case "browser-layout-inspector.remove-style":
      return typeof value.property === "string";
    default:
      return false;
  }
}
function inspectRequest(message, document2) {
  try {
    return {
      ok: true,
      inspection: inspectSelectorLayout(message.selector, document2, {
        referenceSelector: message.referenceSelector,
        computedProperties: message.computedProperties
      })
    };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}
function pageToolRequest(message, controller) {
  try {
    switch (message.type) {
      case "browser-layout-inspector.start-picker":
        controller.startPicker(message.mode);
        break;
      case "browser-layout-inspector.focus-work-item":
        controller.focusWorkItem(message.id);
        break;
      case "browser-layout-inspector.clear-work-item":
        controller.clearWorkItem(message.id);
        break;
      case "browser-layout-inspector.set-work-item-selector":
        controller.setWorkItemSelector(message.id, message.selector);
        break;
      case "browser-layout-inspector.select-tree-node":
        controller.selectTreeNode(message.selector);
        break;
      case "browser-layout-inspector.set-ruler-snap":
        controller.setRulerSnap(message.enabled);
        break;
      case "browser-layout-inspector.clear-ruler-guides":
        controller.clearRulerGuides();
        break;
      case "browser-layout-inspector.apply-style":
        controller.applyStyle(message.property, message.value, message.priority);
        break;
      case "browser-layout-inspector.remove-style":
        controller.removeStyle(message.property);
        break;
      case "browser-layout-inspector.hide-selected":
        controller.hideSelected();
        break;
      case "browser-layout-inspector.restore-selected":
        controller.restoreSelected();
        break;
      case "browser-layout-inspector.restore-all":
        controller.restoreAll();
        break;
      case "browser-layout-inspector.get-state":
        break;
    }
    return { ok: true, state: controller.state() };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error), state: controller.state() };
  }
}
function isPageOverviewRequest(message) {
  return typeof message === "object" && message !== null && (message.type === "browser-layout-inspector.get-dom-tree" || message.type === "browser-layout-inspector.extract-page-styles");
}
function pageOverviewRequest(message, document2) {
  try {
    return message.type === "browser-layout-inspector.get-dom-tree" ? { ok: true, domTree: collectPageDomTree(document2) } : { ok: true, pageStyles: extractPageStyles(document2) };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

// src/content.ts
var pageTools = new PageToolController(document, (state) => {
  chrome.runtime.sendMessage({ type: "browser-layout-inspector.state-changed", state });
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (isInspectSelectorRequest(message)) sendResponse(inspectRequest(message, document));
  else if (isPageOverviewRequest(message)) sendResponse(pageOverviewRequest(message, document));
  else if (isPageToolRequest(message)) sendResponse(pageToolRequest(message, pageTools));
});
//# sourceMappingURL=content.mjs.map
//# sourceMappingURL=content.mjs.map