// ../browser-layout-inspector/dist/index.js
function readDeclarations(style) {
  return Array.from(style).map((property) => ({
    property,
    value: style.getPropertyValue(property).trim(),
    priority: style.getPropertyPriority(property)
  }));
}
function splitSelectorList(selectorText) {
  const selectors = [];
  let start = 0;
  let parenDepth = 0;
  let bracketDepth = 0;
  let quote = null;
  let escaped = false;
  for (let index = 0; index < selectorText.length; index += 1) {
    const character = selectorText[index];
    if (quote) {
      if (escaped) escaped = false;
      else if (character === "\\") escaped = true;
      else if (character === quote) quote = null;
      continue;
    }
    if (character === '"' || character === "'") quote = character;
    else if (character === "(") parenDepth += 1;
    else if (character === ")") parenDepth = Math.max(0, parenDepth - 1);
    else if (character === "[") bracketDepth += 1;
    else if (character === "]") bracketDepth = Math.max(0, bracketDepth - 1);
    else if (character === "," && parenDepth === 0 && bracketDepth === 0) {
      const selector2 = selectorText.slice(start, index).trim();
      if (selector2) selectors.push(selector2);
      start = index + 1;
    }
  }
  const selector = selectorText.slice(start).trim();
  if (selector) selectors.push(selector);
  return selectors;
}
function isActiveCondition(rule, view) {
  const conditionText = rule.conditionText;
  if (!conditionText) return null;
  if (typeof CSSRule !== "undefined" && rule.type === CSSRule.MEDIA_RULE) {
    return view.matchMedia(conditionText).matches ? conditionText : "inactive-media";
  }
  if (typeof CSSRule !== "undefined" && rule.type === CSSRule.SUPPORTS_RULE) {
    return CSS.supports(conditionText) ? conditionText : "inactive-supports";
  }
  return conditionText;
}
function matchesSelector(element, selector) {
  if (selector.includes("::")) return false;
  try {
    return element.matches(selector);
  } catch {
    return false;
  }
}
function readRules(element, rules, view, stylesheetHref, stylesheetLabel2, conditions, path, matches) {
  Array.from(rules).forEach((rule, index) => {
    const nextPath = [...path, index];
    const condition = isActiveCondition(rule, view);
    if (condition === "inactive-media" || condition === "inactive-supports") return;
    const nextConditions = condition ? [...conditions, condition] : conditions;
    if (typeof CSSRule !== "undefined" && rule.type === CSSRule.IMPORT_RULE) {
      const imported = rule;
      if (imported.styleSheet) {
        try {
          readRules(
            element,
            imported.styleSheet.cssRules,
            view,
            imported.href,
            imported.href,
            nextConditions,
            nextPath,
            matches
          );
        } catch {
        }
      }
      return;
    }
    const selectorText = rule.selectorText;
    const style = rule.style;
    if (typeof selectorText === "string" && style) {
      for (const selector of splitSelectorList(selectorText)) {
        if (matchesSelector(element, selector)) {
          matches.push({
            stylesheetHref,
            stylesheetLabel: stylesheetLabel2,
            selector,
            declarations: readDeclarations(style),
            conditions: nextConditions,
            rulePath: nextPath
          });
        }
      }
      return;
    }
    const nestedRules = rule.cssRules;
    if (nestedRules) {
      readRules(element, nestedRules, view, stylesheetHref, stylesheetLabel2, nextConditions, nextPath, matches);
    }
  });
}
function stylesheetLabel(sheet, index) {
  return sheet.href ?? `inline-style-${index + 1}`;
}
function collectCssInfluences(element) {
  const document2 = element.ownerDocument;
  const view = document2.defaultView;
  if (!view) throw new Error("collectCssInfluences requires an element in a browsing context");
  const matchedSelectors = [];
  const inaccessibleStylesheets = [];
  Array.from(document2.styleSheets).forEach((sheet, index) => {
    const label = stylesheetLabel(sheet, index);
    try {
      readRules(element, sheet.cssRules, view, sheet.href, label, [], [], matchedSelectors);
    } catch {
      inaccessibleStylesheets.push({
        stylesheetHref: sheet.href,
        stylesheetLabel: label,
        reason: "css-rules-inaccessible"
      });
    }
  });
  return {
    matchedSelectors,
    inaccessibleStylesheets,
    inlineStyle: element.style ? readDeclarations(element.style) : []
  };
}
function extractComputedStyle(element, properties, pseudoElement = null) {
  const view = element.ownerDocument.defaultView;
  if (!view) throw new Error("extractComputedStyle requires an element in a browsing context");
  const computed = view.getComputedStyle(element, pseudoElement);
  const names = properties ? [...properties] : Array.from(computed);
  const snapshot = {};
  for (const property of names) snapshot[property] = computed.getPropertyValue(property).trim();
  return { pseudoElement, properties: snapshot };
}
function toRect(rect) {
  return {
    x: rect.x,
    y: rect.y,
    top: rect.top,
    right: rect.right,
    bottom: rect.bottom,
    left: rect.left,
    width: rect.width,
    height: rect.height
  };
}
function documentRect(viewport, view) {
  const x = viewport.x + view.scrollX;
  const y = viewport.y + view.scrollY;
  return { ...viewport, x, y, top: viewport.top + view.scrollY, right: viewport.right + view.scrollX, bottom: viewport.bottom + view.scrollY, left: viewport.left + view.scrollX };
}
function extractElementMetrics(element) {
  const view = element.ownerDocument.defaultView;
  if (!view) throw new Error("extractElementMetrics requires an element in a browsing context");
  const html = element;
  const viewportRect = toRect(element.getBoundingClientRect());
  return {
    viewportRect,
    documentRect: documentRect(viewportRect, view),
    clientRects: Array.from(element.getClientRects(), toRect),
    offset: { width: html.offsetWidth ?? 0, height: html.offsetHeight ?? 0, top: html.offsetTop ?? 0, left: html.offsetLeft ?? 0 },
    client: { width: html.clientWidth ?? 0, height: html.clientHeight ?? 0, top: html.clientTop ?? 0, left: html.clientLeft ?? 0 },
    scroll: { width: html.scrollWidth ?? 0, height: html.scrollHeight ?? 0, top: html.scrollTop ?? 0, left: html.scrollLeft ?? 0 },
    devicePixelRatio: view.devicePixelRatio
  };
}
function relation(target, reference, selector, kind) {
  return {
    reference: kind,
    referenceSelector: selector,
    deltaCssPx: { x: target.left - reference.left, y: target.top - reference.top },
    edgeGapsCssPx: {
      leftToRight: target.left - reference.right,
      rightToLeft: reference.left - target.right,
      topToBottom: target.top - reference.bottom,
      bottomToTop: reference.top - target.bottom
    }
  };
}
var NO_RELATION = {
  reference: "none",
  referenceSelector: null,
  deltaCssPx: null,
  edgeGapsCssPx: null
};
function extractPosition(element, referenceElement = null, referenceSelector = null) {
  const metrics = extractElementMetrics(element);
  const html = element;
  const offsetParent = html.offsetParent;
  return {
    viewport: metrics.viewportRect,
    document: metrics.documentRect,
    relativeToReference: referenceElement ? relation(metrics.viewportRect, extractElementMetrics(referenceElement).viewportRect, referenceSelector, "element") : NO_RELATION,
    relativeToOffsetParent: offsetParent ? relation(metrics.viewportRect, extractElementMetrics(offsetParent).viewportRect, null, "offset-parent") : NO_RELATION
  };
}
function inspectElementLayout(element, options = {}) {
  return {
    targetSelector: options.targetSelector ?? null,
    ...options.includeCssInfluences === false ? {} : { cssInfluences: collectCssInfluences(element) },
    computedStyle: extractComputedStyle(element, options.computedProperties, options.pseudoElement),
    metrics: extractElementMetrics(element),
    position: extractPosition(element, options.referenceElement, options.referenceSelector ?? null)
  };
}
function inspectSelectorLayout(selector, document2 = globalThis.document, options = {}) {
  const element = document2.querySelector(selector);
  if (!element) throw new Error(`No element matched selector: ${selector}`);
  const referenceElement = options.referenceSelector ? document2.querySelector(options.referenceSelector) : null;
  return inspectElementLayout(element, { ...options, targetSelector: selector, referenceElement });
}

// src/page-tools.ts
var SNAPSHOT_PROPERTIES = [
  "display",
  "position",
  "width",
  "height",
  "margin",
  "padding",
  "gap",
  "color",
  "background-color",
  "box-sizing",
  "min-width",
  "min-height",
  "max-width",
  "max-height",
  "grid-template-columns",
  "grid-template-rows",
  "grid-column",
  "grid-row",
  "flex-flow",
  "flex-grow",
  "flex-shrink",
  "flex-basis",
  "justify-content",
  "align-items",
  "align-content",
  "overflow",
  "transform"
];
var PageToolController = class {
  constructor(document2, onStateChange) {
    this.document = document2;
    this.onStateChange = onStateChange;
    this.overlay = new Overlay(document2);
    document2.addEventListener("mousemove", this.onPointerMove, true);
    document2.addEventListener("mousedown", this.onMouseDown, true);
    document2.addEventListener("mouseup", this.onMouseUp, true);
    document2.addEventListener("click", this.onClick, true);
    document2.defaultView?.addEventListener("keydown", this.onKeyDown, true);
    document2.defaultView?.addEventListener("scroll", this.refreshOverlay, true);
    document2.defaultView?.addEventListener("resize", this.refreshOverlay);
  }
  selected = null;
  anchor = null;
  measureTarget = null;
  rulerStart = null;
  rulerEnd = null;
  rulerSnapEnabled = false;
  verticalGuides = /* @__PURE__ */ new Set();
  horizontalGuides = /* @__PURE__ */ new Set();
  mode = null;
  consumeNextClick = false;
  changes = /* @__PURE__ */ new Map();
  overlay;
  startPicker(mode) {
    this.mode = mode === "select" ? "select" : mode === "measure" ? "measure-anchor" : "ruler";
    if (mode === "measure") {
      this.anchor = null;
      this.measureTarget = null;
    }
    if (mode === "ruler") {
      this.rulerStart = null;
      this.rulerEnd = null;
    }
    this.overlay.clearHover();
    this.refreshOverlay();
    this.notifyStateChange();
  }
  setRulerSnap(enabled) {
    this.rulerSnapEnabled = enabled;
    this.notifyStateChange();
  }
  pinRulerGuides() {
    if (!this.rulerStart || !this.rulerEnd) throw new Error("\uBA3C\uC800 Ruler\uB97C \uB4DC\uB798\uADF8\uD574 \uCE21\uC815 \uC601\uC5ED\uC744 \uB9CC\uB4DC\uC138\uC694.");
    this.verticalGuides.add(this.rulerStart.x);
    this.verticalGuides.add(this.rulerEnd.x);
    this.horizontalGuides.add(this.rulerStart.y);
    this.horizontalGuides.add(this.rulerEnd.y);
    this.refreshOverlay();
    this.notifyStateChange();
  }
  clearRulerGuides() {
    this.verticalGuides.clear();
    this.horizontalGuides.clear();
    this.refreshOverlay();
    this.notifyStateChange();
  }
  applyStyle(property, value, priority) {
    const element = this.requireSelected();
    const normalizedProperty = property.trim();
    if (!normalizedProperty || /[;:{}]/.test(normalizedProperty)) throw new Error("\uC720\uD6A8\uD55C CSS \uC18D\uC131\uBA85\uC744 \uC785\uB825\uD558\uC138\uC694.");
    const normalizedPriority = priority?.trim().toLowerCase();
    if (normalizedPriority && normalizedPriority !== "important") throw new Error("priority\uB294 important\uB9CC \uC9C0\uC6D0\uD569\uB2C8\uB2E4.");
    this.capture(element, normalizedProperty);
    element.style.setProperty(normalizedProperty, value, normalizedPriority);
    this.refreshOverlay();
    this.notifyStateChange();
  }
  hideSelected() {
    const element = this.requireSelected();
    this.capture(element, "display");
    element.style.setProperty("display", "none", "important");
    this.refreshOverlay();
    this.notifyStateChange();
  }
  restoreSelected() {
    const element = this.requireSelected();
    this.restoreElement(element);
    this.refreshOverlay();
    this.notifyStateChange();
  }
  restoreAll() {
    for (const element of this.changes.keys()) this.restoreElement(element);
    this.refreshOverlay();
    this.notifyStateChange();
  }
  state() {
    const referenceSelector = this.anchor ? selectorFor(this.anchor) : null;
    const inspection = this.selected ? inspectElementLayout(this.selected, {
      targetSelector: selectorFor(this.selected),
      referenceElement: this.anchor,
      referenceSelector,
      computedProperties: SNAPSHOT_PROPERTIES
    }) : null;
    const measurement = this.anchor && this.measureTarget ? {
      anchor: summarize(this.anchor),
      target: summarize(this.measureTarget),
      relative: inspectElementLayout(this.measureTarget, {
        targetSelector: selectorFor(this.measureTarget),
        referenceElement: this.anchor,
        referenceSelector,
        includeCssInfluences: false,
        computedProperties: []
      }).position.relativeToReference
    } : null;
    const ruler = this.rulerStart && this.rulerEnd ? rulerMeasurement(this.rulerStart, this.rulerEnd) : null;
    return {
      environment: environmentFor(this.document),
      pickerMode: this.mode === "select" ? "select" : this.mode === "ruler" ? "ruler" : this.mode ? "measure" : null,
      selected: this.selected ? summarize(this.selected) : null,
      inspection,
      measurement,
      ruler,
      rulerSnapEnabled: this.rulerSnapEnabled,
      guides: { vertical: [...this.verticalGuides].sort((a, b) => a - b), horizontal: [...this.horizontalGuides].sort((a, b) => a - b) },
      changedElementCount: this.changes.size
    };
  }
  onPointerMove = (event) => {
    if (!this.mode) return;
    if (this.mode === "ruler") {
      if (!this.rulerStart) return;
      this.rulerEnd = pointFrom(event, this.rulerSnapEnabled);
      this.overlay.showRuler(this.rulerStart, this.rulerEnd);
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    const element = this.elementFromEvent(event);
    if (element) this.overlay.showHover(element, this.mode === "select" ? "#2563eb" : "#f59e0b");
  };
  onMouseDown = (event) => {
    if (this.mode !== "ruler" || event.button !== 0) return;
    this.rulerStart = pointFrom(event, this.rulerSnapEnabled);
    this.rulerEnd = this.rulerStart;
    this.overlay.showRuler(this.rulerStart, this.rulerEnd);
    event.preventDefault();
    event.stopImmediatePropagation();
  };
  onMouseUp = (event) => {
    if (this.mode !== "ruler" || event.button !== 0 || !this.rulerStart) return;
    this.rulerEnd = pointFrom(event, this.rulerSnapEnabled);
    this.mode = null;
    this.consumeNextClick = true;
    this.refreshOverlay();
    this.notifyStateChange();
    event.preventDefault();
    event.stopImmediatePropagation();
  };
  onClick = (event) => {
    if (this.consumeNextClick) {
      this.consumeNextClick = false;
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    if (!this.mode || event.button !== 0) return;
    const element = this.elementFromEvent(event);
    if (!element) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (this.mode === "select") {
      this.selected = element;
      this.mode = null;
    } else if (this.mode === "measure-anchor") {
      this.anchor = element;
      this.measureTarget = null;
      this.mode = "measure-target";
    } else {
      this.measureTarget = element;
      this.selected = element;
      this.mode = null;
    }
    this.overlay.clearHover();
    this.refreshOverlay();
    this.notifyStateChange();
  };
  onKeyDown = (event) => {
    if (event.key !== "Escape" || !this.mode) return;
    this.mode = null;
    this.overlay.clearHover();
    this.notifyStateChange();
  };
  refreshOverlay = () => {
    this.overlay.showSelected(this.selected);
    this.overlay.showMeasurement(this.anchor, this.measureTarget);
    this.overlay.showRuler(this.rulerStart, this.rulerEnd);
    this.overlay.showGuides(this.verticalGuides, this.horizontalGuides);
  };
  elementFromEvent(event) {
    const target = event.target;
    if (!(target instanceof Element) || this.overlay.contains(target)) return null;
    return target;
  }
  requireSelected() {
    if (!this.selected) throw new Error("\uBA3C\uC800 \uD398\uC774\uC9C0\uC5D0\uC11C \uC694\uC18C\uB97C \uC120\uD0DD\uD558\uC138\uC694.");
    return this.selected;
  }
  capture(element, property) {
    let elementChanges = this.changes.get(element);
    if (!elementChanges) {
      elementChanges = /* @__PURE__ */ new Map();
      this.changes.set(element, elementChanges);
    }
    if (elementChanges.has(property)) return;
    const style = element.style;
    const value = style.getPropertyValue(property);
    elementChanges.set(property, { value, priority: style.getPropertyPriority(property), wasPresent: value !== "" });
  }
  restoreElement(element) {
    const elementChanges = this.changes.get(element);
    if (!elementChanges) return;
    const style = element.style;
    for (const [property, original] of elementChanges) {
      if (original.wasPresent) style.setProperty(property, original.value, original.priority);
      else style.removeProperty(property);
    }
    this.changes.delete(element);
  }
  notifyStateChange() {
    this.onStateChange?.(this.state());
  }
};
var Overlay = class {
  root;
  hover = this.createBox();
  selected = this.createBox();
  anchor = this.createBox();
  target = this.createBox();
  measureLabel;
  ruler;
  rulerLabel;
  guides;
  constructor(document2) {
    this.root = document2.createElement("div");
    this.root.setAttribute("data-browser-layout-inspector-ui", "true");
    Object.assign(this.root.style, { position: "fixed", inset: "0", zIndex: "2147483647", pointerEvents: "none" });
    this.measureLabel = document2.createElement("div");
    Object.assign(this.measureLabel.style, {
      position: "fixed",
      display: "none",
      maxWidth: "340px",
      padding: "5px 7px",
      borderRadius: "4px",
      background: "#172033",
      color: "#fff",
      font: "12px/1.35 ui-monospace, SFMono-Regular, monospace",
      boxShadow: "0 2px 8px rgb(0 0 0 / 0.25)"
    });
    this.ruler = document2.createElement("div");
    Object.assign(this.ruler.style, { position: "fixed", display: "none", boxSizing: "border-box", border: "1px dashed #7c3aed", background: "rgb(124 58 237 / 0.08)" });
    this.rulerLabel = document2.createElement("div");
    Object.assign(this.rulerLabel.style, {
      position: "absolute",
      left: "-1px",
      top: "-23px",
      padding: "4px 6px",
      borderRadius: "4px",
      whiteSpace: "nowrap",
      background: "#6d28d9",
      color: "#fff",
      font: "12px/1.25 ui-monospace, SFMono-Regular, monospace",
      boxShadow: "0 2px 8px rgb(0 0 0 / 0.25)"
    });
    this.ruler.append(this.rulerLabel);
    this.guides = document2.createElement("div");
    Object.assign(this.guides.style, { position: "fixed", inset: "0", pointerEvents: "none" });
    this.root.append(this.guides, this.hover, this.selected, this.anchor, this.target, this.measureLabel, this.ruler);
    document2.documentElement.append(this.root);
  }
  contains(element) {
    return this.root.contains(element);
  }
  clearHover() {
    this.hover.style.display = "none";
  }
  showHover(element, color) {
    this.showBox(this.hover, element, color, "hover");
  }
  showSelected(element) {
    if (!element || !element.isConnected) return this.hide(this.selected);
    this.showBox(this.selected, element, "#2563eb", `\uC120\uD0DD \xB7 ${selectorFor(element)}`);
  }
  showMeasurement(anchor, target) {
    if (!anchor || !anchor.isConnected) this.hide(this.anchor);
    else this.showBox(this.anchor, anchor, "#f59e0b", `A \xB7 ${selectorFor(anchor)}`);
    if (!target || !target.isConnected) {
      this.hide(this.target);
      this.measureLabel.style.display = "none";
      return;
    }
    this.showBox(this.target, target, "#ef4444", `B \xB7 ${selectorFor(target)}`);
    if (!anchor || !anchor.isConnected) return;
    const a = anchor.getBoundingClientRect();
    const b = target.getBoundingClientRect();
    this.measureLabel.textContent = `A \u2192 B  \u0394x ${round(b.left - a.left)}px \xB7 \u0394y ${round(b.top - a.top)}px  |  A.right\u2192B.left ${round(b.left - a.right)}px \xB7 A.bottom\u2192B.top ${round(b.top - a.bottom)}px`;
    Object.assign(this.measureLabel.style, { display: "block", left: `${Math.max(8, Math.min(b.left, window.innerWidth - 348))}px`, top: `${Math.max(8, Math.min(b.bottom + 8, window.innerHeight - 52))}px` });
  }
  showRuler(start, end) {
    if (!start || !end) {
      this.ruler.style.display = "none";
      return;
    }
    const measurement = rulerMeasurement(start, end);
    Object.assign(this.ruler.style, {
      display: "block",
      left: `${Math.min(start.x, end.x)}px`,
      top: `${Math.min(start.y, end.y)}px`,
      width: `${measurement.width}px`,
      height: `${measurement.height}px`
    });
    this.rulerLabel.textContent = `Ruler \xB7 W ${measurement.width}px \xB7 H ${measurement.height}px \xB7 \u2197 ${measurement.distance}px \xB7 \u2220 ${measurement.angle}\xB0`;
  }
  showGuides(vertical, horizontal) {
    this.guides.replaceChildren();
    for (const x of vertical) this.guides.append(this.createGuide("vertical", x));
    for (const y of horizontal) this.guides.append(this.createGuide("horizontal", y));
  }
  createBox() {
    const box = this.root?.ownerDocument.createElement("div") ?? document.createElement("div");
    Object.assign(box.style, {
      position: "fixed",
      display: "none",
      boxSizing: "border-box",
      border: "2px solid",
      background: "rgb(37 99 235 / 0.08)",
      color: "#fff",
      font: "11px/1.25 ui-monospace, SFMono-Regular, monospace"
    });
    const label = box.ownerDocument.createElement("span");
    label.dataset.role = "label";
    Object.assign(label.style, { position: "absolute", left: "-2px", top: "-20px", maxWidth: "330px", padding: "2px 4px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", background: "#2563eb" });
    box.append(label);
    return box;
  }
  createGuide(direction, value) {
    const guide = this.guides.ownerDocument.createElement("div");
    guide.setAttribute("data-browser-layout-inspector-guide", direction);
    Object.assign(guide.style, direction === "vertical" ? { position: "fixed", left: `${value}px`, top: "0", bottom: "0", borderLeft: "1px dashed #d946ef" } : { position: "fixed", left: "0", right: "0", top: `${value}px`, borderTop: "1px dashed #d946ef" });
    return guide;
  }
  showBox(box, element, color, label) {
    const rect = element.getBoundingClientRect();
    const labelElement = box.querySelector('[data-role="label"]');
    Object.assign(box.style, { display: "block", left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px`, borderColor: color, backgroundColor: `${color}16` });
    labelElement.style.background = color;
    labelElement.textContent = `${label} \xB7 ${round(rect.width)} \xD7 ${round(rect.height)}`;
  }
  hide(element) {
    element.style.display = "none";
  }
};
function summarize(element) {
  const text = element.textContent?.trim().replace(/\s+/g, " ") ?? "";
  return { selector: selectorFor(element), tagName: element.tagName.toLowerCase(), text: text ? text.slice(0, 80) : null };
}
function environmentFor(document2) {
  const view = document2.defaultView;
  if (!view) throw new Error("page measurement requires a browsing context");
  const viewport = view.visualViewport;
  return {
    url: document2.location.href,
    viewportCssPx: { width: view.innerWidth, height: view.innerHeight },
    scrollCssPx: { x: view.scrollX, y: view.scrollY },
    devicePixelRatio: view.devicePixelRatio,
    visualViewport: viewport ? { width: viewport.width, height: viewport.height, scale: viewport.scale } : null
  };
}
function selectorFor(element) {
  const id = element.getAttribute("id");
  if (id) return `#${cssEscape(id)}`;
  for (const attribute of ["data-testid", "data-qa-id", "data-measure-id"]) {
    const value = element.getAttribute(attribute);
    if (value) return `[${attribute}="${cssStringEscape(value)}"]`;
  }
  const segments = [];
  let current = element;
  while (current && current !== current.ownerDocument.documentElement && segments.length < 4) {
    const name = current.tagName.toLowerCase();
    const siblings = current.parentElement ? [...current.parentElement.children].filter((sibling) => sibling.tagName === current.tagName) : [];
    const index = siblings.indexOf(current) + 1;
    segments.unshift(`${name}:nth-of-type(${Math.max(index, 1)})`);
    current = current.parentElement;
  }
  return segments.join(" > ") || element.tagName.toLowerCase();
}
function cssEscape(value) {
  const escape = globalThis.CSS?.escape;
  return escape ? escape(value) : value.replace(/[^a-zA-Z0-9_-]/g, "\\$&");
}
function cssStringEscape(value) {
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}
function round(value) {
  return Math.round(value * 100) / 100;
}
function pointFrom(event, snapToGrid = false) {
  const point = { x: round(event.clientX), y: round(event.clientY) };
  return snapToGrid ? { x: snap(point.x), y: snap(point.y) } : point;
}
function rulerMeasurement(start, end) {
  const width = round(Math.abs(end.x - start.x));
  const height = round(Math.abs(end.y - start.y));
  return { start, end, width, height, distance: round(Math.hypot(width, height)), angle: round(Math.atan2(end.y - start.y, end.x - start.x) * (180 / Math.PI)) };
}
function snap(value) {
  return Math.round(value / 8) * 8;
}

// src/protocol.ts
function isInspectSelectorRequest(message) {
  return typeof message === "object" && message !== null && message.type === "browser-layout-inspector.inspect-selector" && typeof message.selector === "string";
}
function isPageToolRequest(message) {
  if (typeof message !== "object" || message === null) return false;
  const value = message;
  switch (value.type) {
    case "browser-layout-inspector.start-picker":
      return value.mode === "select" || value.mode === "measure" || value.mode === "ruler";
    case "browser-layout-inspector.get-state":
    case "browser-layout-inspector.pin-ruler-guides":
    case "browser-layout-inspector.clear-ruler-guides":
    case "browser-layout-inspector.hide-selected":
    case "browser-layout-inspector.restore-selected":
    case "browser-layout-inspector.restore-all":
      return true;
    case "browser-layout-inspector.set-ruler-snap":
      return typeof value.enabled === "boolean";
    case "browser-layout-inspector.apply-style":
      return typeof value.property === "string" && typeof value.value === "string" && (value.priority === void 0 || typeof value.priority === "string");
    default:
      return false;
  }
}
function inspectRequest(message, document2) {
  try {
    return {
      ok: true,
      inspection: inspectSelectorLayout(message.selector, document2, {
        referenceSelector: message.referenceSelector,
        computedProperties: message.computedProperties
      })
    };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}
function pageToolRequest(message, controller) {
  try {
    switch (message.type) {
      case "browser-layout-inspector.start-picker":
        controller.startPicker(message.mode);
        break;
      case "browser-layout-inspector.set-ruler-snap":
        controller.setRulerSnap(message.enabled);
        break;
      case "browser-layout-inspector.pin-ruler-guides":
        controller.pinRulerGuides();
        break;
      case "browser-layout-inspector.clear-ruler-guides":
        controller.clearRulerGuides();
        break;
      case "browser-layout-inspector.apply-style":
        controller.applyStyle(message.property, message.value, message.priority);
        break;
      case "browser-layout-inspector.hide-selected":
        controller.hideSelected();
        break;
      case "browser-layout-inspector.restore-selected":
        controller.restoreSelected();
        break;
      case "browser-layout-inspector.restore-all":
        controller.restoreAll();
        break;
      case "browser-layout-inspector.get-state":
        break;
    }
    return { ok: true, state: controller.state() };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error), state: controller.state() };
  }
}

// src/content.ts
var pageTools = new PageToolController(document, (state) => {
  chrome.runtime.sendMessage({ type: "browser-layout-inspector.state-changed", state });
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (isInspectSelectorRequest(message)) sendResponse(inspectRequest(message, document));
  else if (isPageToolRequest(message)) sendResponse(pageToolRequest(message, pageTools));
});
//# sourceMappingURL=content.mjs.map
//# sourceMappingURL=content.mjs.map