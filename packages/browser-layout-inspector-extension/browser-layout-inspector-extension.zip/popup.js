(function () {
  'use strict';

  // src/css-output.ts
  function formatInspectionAsCss(inspection) {
    const selector = inspection.targetSelector ?? ":root";
    const sections = [
      "/* Computed CSS snapshot \u2014 final values for the current page state. */",
      formatRule(selector, Object.entries(inspection.computedStyle.properties).map(([property, value]) => ({ property, value, priority: "" })), false)
    ];
    const influences = inspection.cssInfluences;
    if (!influences) return sections.join("\n\n");
    if (influences.inlineStyle.length > 0) {
      sections.push("/* Existing inline style before any extension edit. */", formatRule(selector, influences.inlineStyle, false));
    }
    if (influences.matchedSelectors.length > 0) {
      sections.push("/* Matched author CSS candidates \u2014 inspect the computed block above for final winners. */");
      for (const match of influences.matchedSelectors) sections.push(formatSourceRule(match));
    }
    if (influences.inaccessibleStylesheets.length > 0) {
      sections.push(`/* CSSOM unavailable: ${influences.inaccessibleStylesheets.map((sheet) => safeComment(sheet.stylesheetHref ?? sheet.stylesheetLabel)).join(", ")} */`);
    }
    return sections.join("\n\n");
  }
  function formatSourceRule(match) {
    const source = match.stylesheetHref ?? match.stylesheetLabel;
    const conditions = match.conditions.length > 0 ? `; active when ${match.conditions.join(" \u2192 ")}` : "";
    return `/* Source: ${safeComment(source)}${safeComment(conditions)} */
${formatRule(match.selector, match.declarations, true)}`;
  }
  function formatRule(selector, declarations, keepEmpty) {
    const lines = declarations.filter((declaration) => keepEmpty || declaration.value !== "").map((declaration) => `  ${declaration.property}: ${declaration.value}${declaration.priority ? ` !${declaration.priority}` : ""};`);
    return `${selector} {
${lines.join("\n")}
}`;
  }
  function safeComment(value) {
    return value.replaceAll("*/", "* /").replaceAll("\n", " ");
  }

  // src/json-output.ts
  function createLayoutExchange(state, exportedAt = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      schemaVersion: "browser-layout-inspector.exchange.v1",
      exportedAt,
      environment: state.environment,
      selected: state.selected,
      workItems: state.workItems,
      inspection: state.inspection,
      cssInspector: state.cssInspector,
      elementMeasurement: state.measurement,
      ruler: state.ruler,
      rulerSnapEnabled: state.rulerSnapEnabled,
      guides: state.guides,
      changedElementCount: state.changedElementCount
    };
  }
  function formatLayoutExchangeJson(state) {
    return `${JSON.stringify(createLayoutExchange(state), null, 2)}
`;
  }

  // src/popup.ts
  var output = requiredElement("output");
  var selection = requiredElement("selection");
  var pickSelectButton = requiredElement("pick-select");
  var pickAutoSelectButton = requiredElement("pick-auto-select");
  var pickMeasureButton = requiredElement("pick-measure");
  var rulerButton = requiredElement("ruler");
  var rulerSnapInput = requiredElement("ruler-snap");
  var clearGuidesButton = requiredElement("clear-guides");
  var guideCount = requiredElement("guide-count");
  var workItems = requiredElement("work-items");
  var refreshDomTreeButton = requiredElement("refresh-dom-tree");
  var domTree = requiredElement("dom-tree");
  var extractPageStylesButton = requiredElement("extract-page-styles");
  var copyPageStylesButton = requiredElement("copy-page-styles");
  var downloadPageStylesButton = requiredElement("download-page-styles");
  var pageStyleOutput = requiredElement("page-style-output");
  var copyCssButton = requiredElement("copy-css");
  var copyJsonButton = requiredElement("copy-json");
  var downloadJsonButton = requiredElement("download-json");
  var exportPngButton = requiredElement("export-png");
  var refreshButton = requiredElement("refresh");
  var styleProperty = requiredInput("style-property");
  var styleValue = requiredInput("style-value");
  var styleImportant = requiredElement("style-important");
  var applyStyleButton = requiredElement("apply-style");
  var inlineDeclarations = requiredElement("inline-declarations");
  var authorDeclarations = requiredElement("author-declarations");
  var computedFilter = requiredInput("computed-filter");
  var computedDeclarations = requiredElement("computed-declarations");
  var hideButton = requiredElement("hide-selected");
  var restoreSelectedButton = requiredElement("restore-selected");
  var restoreAllButton = requiredElement("restore-all");
  var selectorInput = requiredInput("selector");
  var referenceInput = requiredInput("reference-selector");
  var propertiesInput = requiredInput("properties");
  var inspectButton = requiredElement("inspect");
  var lastState = null;
  var lastPageStyles = null;
  pickSelectButton.addEventListener(
    "click",
    () => void run(
      { type: "browser-layout-inspector.start-picker", mode: "select" },
      "\uD398\uC774\uC9C0\uC5D0\uC11C \uC694\uC18C\uB97C \uD074\uB9AD\uD574 \uC120\uD0DD\uD558\uC138\uC694. Side Panel\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB85C \uC720\uC9C0\uB429\uB2C8\uB2E4."
    )
  );
  pickAutoSelectButton.addEventListener(
    "click",
    () => void run(
      { type: "browser-layout-inspector.start-picker", mode: "auto-select" },
      "hover \uB300\uC0C1\uC774 \uC790\uB3D9 \uC120\uD0DD\uB429\uB2C8\uB2E4. Delete/Backspace\uB85C \uC228\uAE30\uACE0 Escape\uB85C \uB05D\uB0C5\uB2C8\uB2E4."
    )
  );
  pickMeasureButton.addEventListener(
    "click",
    () => void run(
      { type: "browser-layout-inspector.start-picker", mode: "measure" },
      "\uAE30\uC900 A\uC640 \uB300\uC0C1 B\uB97C \uCC28\uB840\uB85C \uD074\uB9AD\uD558\uC138\uC694. Side Panel\uC5D0\uC11C \uACB0\uACFC\uAC00 \uC790\uB3D9 \uAC31\uC2E0\uB429\uB2C8\uB2E4."
    )
  );
  rulerButton.addEventListener(
    "click",
    () => void run(
      { type: "browser-layout-inspector.start-picker", mode: "ruler" },
      "\uD398\uC774\uC9C0\uC5D0\uC11C \uC2DC\uC791\uC810\uBD80\uD130 \uB05D\uC810\uAE4C\uC9C0 \uB4DC\uB798\uADF8\uD558\uC138\uC694. \uC694\uC18C\uB97C \uC120\uD0DD\uD558\uC9C0 \uC54A\uB294 \uC790\uC720 Ruler\uC785\uB2C8\uB2E4."
    )
  );
  rulerSnapInput.addEventListener(
    "change",
    () => void run({ type: "browser-layout-inspector.set-ruler-snap", enabled: rulerSnapInput.checked })
  );
  clearGuidesButton.addEventListener(
    "click",
    () => void run({ type: "browser-layout-inspector.clear-ruler-guides" })
  );
  refreshDomTreeButton.addEventListener(
    "click",
    () => void run({ type: "browser-layout-inspector.get-dom-tree" })
  );
  extractPageStylesButton.addEventListener(
    "click",
    () => void run({ type: "browser-layout-inspector.extract-page-styles" })
  );
  copyPageStylesButton.addEventListener("click", () => void copyPageStyles());
  downloadPageStylesButton.addEventListener("click", () => downloadPageStyles());
  copyCssButton.addEventListener("click", () => void copyCss());
  copyJsonButton.addEventListener("click", () => void copyJson());
  downloadJsonButton.addEventListener("click", () => downloadJson());
  exportPngButton.addEventListener("click", () => void exportViewportPng());
  refreshButton.addEventListener(
    "click",
    () => void run({ type: "browser-layout-inspector.get-state" })
  );
  applyStyleButton.addEventListener(
    "click",
    () => void run({
      type: "browser-layout-inspector.apply-style",
      property: styleProperty.value,
      value: styleValue.value,
      ...styleImportant.checked ? { priority: "important" } : {}
    })
  );
  computedFilter.addEventListener("input", () => renderCssInspector(lastState));
  hideButton.addEventListener(
    "click",
    () => void run({ type: "browser-layout-inspector.hide-selected" })
  );
  restoreSelectedButton.addEventListener(
    "click",
    () => void run({ type: "browser-layout-inspector.restore-selected" })
  );
  restoreAllButton.addEventListener(
    "click",
    () => void run({ type: "browser-layout-inspector.restore-all" })
  );
  inspectButton.addEventListener("click", () => {
    const selector = selectorInput.value.trim();
    if (!selector) return renderError("CSS selector\uB97C \uC785\uB825\uD558\uC138\uC694.");
    void run({
      type: "browser-layout-inspector.inspect-selector",
      selector,
      ...referenceInput.value.trim() ? { referenceSelector: referenceInput.value.trim() } : {},
      ...propertiesInput.value.trim() ? {
        computedProperties: propertiesInput.value.split(",").map((property) => property.trim()).filter(Boolean)
      } : {}
    });
  });
  void initializePanel();
  chrome.runtime.onMessage.addListener((message) => {
    if (!isStateChangedMessage(message)) return;
    renderState(message.state);
  });
  async function run(request, notice) {
    setBusy(true);
    try {
      const tabId = await activeTabId();
      const response = await requestInTab(tabId, request);
      render(response, notice);
    } catch (error) {
      renderError(error instanceof Error ? error.message : String(error));
    } finally {
      setBusy(false);
    }
  }
  async function initializePanel() {
    await run({ type: "browser-layout-inspector.get-state" });
    await run({ type: "browser-layout-inspector.get-dom-tree" });
  }
  function render(response, notice) {
    if (!response.ok) return renderError(response.error ?? "\uC694\uCCAD\uC744 \uCC98\uB9AC\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    if ("domTree" in response) renderDomTree(response.domTree ?? null);
    else if ("pageStyles" in response && response.pageStyles) renderPageStyles(response.pageStyles);
    else if ("state" in response && response.state) renderState(response.state, notice);
    else if ("inspection" in response) {
      selection.textContent = response.inspection?.targetSelector ?? "\uC218\uB3D9 \uAC80\uC0AC \uACB0\uACFC";
      output.textContent = response.inspection ? formatInspectionAsCss(response.inspection) : "/* \uAC80\uC0AC \uACB0\uACFC\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. */";
    }
  }
  function renderDomTree(root) {
    if (!root) return renderEmpty(domTree, "\uD604\uC7AC \uD398\uC774\uC9C0\uC5D0\uC11C body \uC694\uC18C\uB97C \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    domTree.replaceChildren(renderDomTreeNode(root));
  }
  function renderDomTreeNode(node) {
    const choose = document.createElement("button");
    choose.type = "button";
    choose.className = "dom-tree-node";
    choose.textContent = node.label;
    choose.title = `${node.selector} \uC120\uD0DD`;
    choose.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void run({ type: "browser-layout-inspector.select-tree-node", selector: node.selector });
    });
    if (node.children.length === 0 && !node.truncated) return choose;
    const details = document.createElement("details");
    details.open = node.selector === "body";
    const summary = document.createElement("summary");
    summary.append(choose, document.createTextNode(` \xB7 ${node.childCount} children`));
    const children = document.createElement("div");
    children.className = "dom-tree-children";
    children.append(...node.children.map(renderDomTreeNode));
    if (node.truncated) {
      const truncated = document.createElement("div");
      truncated.className = "dom-tree-truncated";
      truncated.textContent = `\u2026 ${Math.max(node.childCount - node.children.length, 0)} child nodes omitted`;
      children.append(truncated);
    }
    details.append(summary, children);
    return details;
  }
  function renderPageStyles(styles) {
    lastPageStyles = styles;
    pageStyleOutput.textContent = styles.css;
  }
  function renderState(state, notice) {
    lastState = state;
    pickSelectButton.textContent = state.pickerMode === "select" ? "\uC694\uC18C \uC120\uD0DD \uC911\u2026" : "\uC694\uC18C \uC120\uD0DD";
    pickAutoSelectButton.textContent = state.pickerMode === "auto-select" ? "\uC790\uB3D9 \uC120\uD0DD \uC911\u2026 (Esc)" : "\uC790\uB3D9 \uC120\uD0DD";
    pickMeasureButton.textContent = state.pickerMode === "measure" ? "A \uC120\uD0DD \uC911\u2026" : "\uC694\uC18C \uAC04\uACA9 (A \u2192 B)";
    rulerButton.textContent = state.pickerMode === "ruler" ? "Ruler \uB4DC\uB798\uADF8 \uC911\u2026" : "Ruler";
    selection.textContent = state.selected ? `${state.selected.selector} (${state.selected.tagName})` : "\uC120\uD0DD\uB41C \uC694\uC18C \uC5C6\uC74C";
    renderWorkItems(state);
    rulerSnapInput.checked = state.rulerSnapEnabled;
    guideCount.textContent = `Ruler \uAC00\uC774\uB4DC ${state.guides.vertical.length + state.guides.horizontal.length}\uAC1C`;
    clearGuidesButton.disabled = state.guides.vertical.length + state.guides.horizontal.length === 0;
    renderCssInspector(state);
    output.textContent = formatStateAsCss(state, notice);
  }
  function renderWorkItems(state) {
    if (state.workItems.length === 0) {
      renderEmpty(workItems, "\uC77C\uBC18 \uC120\uD0DD, \uBE44\uAD50 A/B, Ruler box\uAC00 \uC5EC\uAE30\uC5D0 \uB0A8\uC2B5\uB2C8\uB2E4.");
      return;
    }
    workItems.replaceChildren(
      ...state.workItems.map((item) => {
        const row = document.createElement("div");
        row.className = "work-item";
        const focus = document.createElement("button");
        focus.type = "button";
        focus.className = `work-item-focus${item.active ? " active" : ""}`;
        focus.title = `${item.label}: ${item.detail}`;
        const label = document.createElement("span");
        label.className = "work-item-label";
        label.textContent = item.role;
        const detail = document.createElement("span");
        detail.className = "work-item-detail";
        detail.textContent = item.id === "ruler" ? item.detail : item.label;
        focus.append(label, detail);
        focus.addEventListener(
          "click",
          () => void run({ type: "browser-layout-inspector.focus-work-item", id: item.id })
        );
        const clear = document.createElement("button");
        clear.type = "button";
        clear.className = "work-item-clear";
        clear.textContent = "\uC120\uD0DD \uD574\uC81C";
        clear.setAttribute("aria-label", `${item.label} \uC120\uD0DD \uD574\uC81C`);
        clear.addEventListener(
          "click",
          () => void run({ type: "browser-layout-inspector.clear-work-item", id: item.id })
        );
        row.append(focus, clear);
        if (item.selectorCandidates.length > 0 && item.selectedSelector) {
          const selector = document.createElement("select");
          selector.className = "work-item-selector";
          selector.title = "\uC774 \uC791\uC5C5 \uD56D\uBAA9\uC5D0 \uD45C\uC2DC\xB7\uBCF5\uC0AC\uD560 selector \uC120\uD0DD";
          for (const candidate of item.selectorCandidates) {
            const option = document.createElement("option");
            option.value = candidate.selector;
            option.selected = candidate.selector === item.selectedSelector;
            option.textContent = `${selectorSourceLabel(candidate.source, candidate.unique)} \xB7 ${candidate.selector}`;
            selector.append(option);
          }
          selector.addEventListener(
            "change",
            () => void run({
              type: "browser-layout-inspector.set-work-item-selector",
              id: item.id,
              selector: selector.value
            })
          );
          row.append(selector);
        }
        return row;
      })
    );
  }
  function selectorSourceLabel(source, unique) {
    if (source === "matched-css") return unique ? "\uB9E4\uCE6D CSS \xB7 \uACE0\uC720" : "\uB9E4\uCE6D CSS";
    if (source === "unique") return "\uACE0\uC720 \uC2DD\uBCC4\uC790";
    return unique ? "\uAD6C\uC870 \xB7 \uACE0\uC720" : "\uAD6C\uC870";
  }
  function renderCssInspector(state) {
    if (!state?.cssInspector) {
      renderEmpty(inlineDeclarations, "\uC694\uC18C\uB97C \uC120\uD0DD\uD558\uBA74 inline declaration\uC744 \uD3B8\uC9D1\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.");
      renderEmpty(authorDeclarations, "\uC120\uD0DD\uB41C \uC694\uC18C\uC758 CSS source \uD6C4\uBCF4\uAC00 \uD45C\uC2DC\uB429\uB2C8\uB2E4.");
      renderEmpty(computedDeclarations, "\uC120\uD0DD\uB41C \uC694\uC18C\uC758 \uCD5C\uC885 computed \uAC12\uC774 \uD45C\uC2DC\uB429\uB2C8\uB2E4.");
      return;
    }
    const inline = state.cssInspector.sourceDeclarations.filter(
      (declaration) => declaration.source === "inline"
    );
    renderInlineDeclarations(inline);
    renderAuthorDeclarations(
      state.cssInspector.sourceDeclarations.filter((declaration) => declaration.source === "author")
    );
    const query = computedFilter.value.trim().toLowerCase();
    renderComputedDeclarations(
      state.cssInspector.computedDeclarations.filter(
        (declaration) => !query || declaration.property.includes(query) || declaration.value.toLowerCase().includes(query)
      )
    );
  }
  function renderInlineDeclarations(declarations) {
    if (declarations.length === 0)
      return renderEmpty(
        inlineDeclarations,
        "\uD604\uC7AC inline declaration\uC774 \uC5C6\uC2B5\uB2C8\uB2E4. \uC704\uC5D0\uC11C \uCD94\uAC00\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4."
      );
    inlineDeclarations.replaceChildren(
      ...declarations.map((declaration) => {
        const row = document.createElement("div");
        row.className = "declaration-row";
        const property = input(declaration.property, "CSS \uC18D\uC131");
        const value = input(declaration.value, "\uAC12");
        const save = document.createElement("button");
        save.type = "button";
        save.textContent = "\uC801\uC6A9";
        save.addEventListener(
          "click",
          () => void run({
            type: "browser-layout-inspector.apply-style",
            property: property.value,
            value: value.value,
            ...declaration.priority ? { priority: declaration.priority } : {}
          })
        );
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "remove";
        remove.textContent = "\uC0AD\uC81C";
        remove.addEventListener(
          "click",
          () => void run({
            type: "browser-layout-inspector.remove-style",
            property: declaration.property
          })
        );
        row.append(property, value, save, remove);
        return row;
      })
    );
  }
  function renderAuthorDeclarations(declarations) {
    if (declarations.length === 0)
      return renderEmpty(authorDeclarations, "\uC811\uADFC \uAC00\uB2A5\uD55C author declaration \uD6C4\uBCF4\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4.");
    authorDeclarations.replaceChildren(
      ...declarations.map((declaration) => {
        const row = document.createElement("div");
        row.className = "declaration-row";
        const property = document.createElement("span");
        property.textContent = declaration.property;
        const value = document.createElement("span");
        value.textContent = `${declaration.value}${declaration.priority ? " !important" : ""}`;
        const source = document.createElement("span");
        source.className = "declaration-meta";
        source.textContent = `${declaration.stylesheetLabel} \xB7 ${declaration.selector ?? "(inline)"}${declaration.conditions.length ? ` \xB7 ${declaration.conditions.join(", ")}` : ""}`;
        row.append(property, value, source);
        return row;
      })
    );
  }
  function renderComputedDeclarations(declarations) {
    if (declarations.length === 0)
      return renderEmpty(computedDeclarations, "\uD544\uD130\uC640 \uC77C\uCE58\uD558\uB294 computed declaration\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.");
    computedDeclarations.replaceChildren(
      ...declarations.map((declaration) => {
        const row = document.createElement("div");
        row.className = "computed-row";
        const property = document.createElement("span");
        property.textContent = declaration.property;
        const value = document.createElement("span");
        value.textContent = declaration.value;
        row.append(property, value);
        return row;
      })
    );
  }
  function renderEmpty(container, message) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = message;
    container.replaceChildren(empty);
  }
  function input(value, placeholder) {
    const element = document.createElement("input");
    element.value = value;
    element.placeholder = placeholder;
    return element;
  }
  function renderError(error) {
    output.textContent = `/* \uC624\uB958: ${safeComment2(error)} */`;
  }
  function formatStateAsCss(state, notice) {
    const notes = [
      notice ? `\uC0C1\uD0DC: ${notice}` : null,
      state.pickerMode ? `\uB3C4\uAD6C: ${state.pickerMode} \uD65C\uC131` : null,
      state.measurement ? `A \u2192 B DOM edge gap \u2014 \u0394x ${state.measurement.relative.deltaCssPx?.x ?? "n/a"}px, \u0394y ${state.measurement.relative.deltaCssPx?.y ?? "n/a"}px; A.right \u2192 B.left ${state.measurement.relative.edgeGapsCssPx?.leftToRight ?? "n/a"}px; A.bottom \u2192 B.top ${state.measurement.relative.edgeGapsCssPx?.topToBottom ?? "n/a"}px.` : null,
      state.ruler ? `Ruler viewport \u2014 start (${state.ruler.start.x}, ${state.ruler.start.y}), end (${state.ruler.end.x}, ${state.ruler.end.y}); width ${state.ruler.width}px; height ${state.ruler.height}px; diagonal ${state.ruler.distance}px.` : null,
      state.ruler ? `Ruler angle: ${state.ruler.angle}\xB0; 8px snap ${state.rulerSnapEnabled ? "on" : "off"}; current Ruler guides ${state.guides.vertical.length + state.guides.horizontal.length}.` : null,
      state.changedElementCount > 0 ? `\uC784\uC2DC inline \uBCC0\uACBD \uC694\uC18C: ${state.changedElementCount}\uAC1C (\uC6D0\uBCF5 \uAC00\uB2A5)` : null
    ].filter((note) => note !== null);
    const inspection = state.inspection ? formatInspectionAsCss(state.inspection) : "/* \uD398\uC774\uC9C0\uC5D0\uC11C \uC694\uC18C\uB97C \uC120\uD0DD\uD558\uBA74 copyable computed CSS\uAC00 \uD45C\uC2DC\uB429\uB2C8\uB2E4. */";
    return `${notes.length > 0 ? `/*
${notes.map((note) => ` * ${safeComment2(note)}`).join("\n")}
 */

` : ""}${inspection}`;
  }
  async function copyCss() {
    try {
      await navigator.clipboard.writeText(output.textContent ?? "");
      flashButton(copyCssButton, "\uBCF5\uC0AC\uB428", "CSS \uBCF5\uC0AC");
    } catch (error) {
      renderError(`\uD074\uB9BD\uBCF4\uB4DC \uBCF5\uC0AC \uC2E4\uD328: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  async function copyPageStyles() {
    try {
      await navigator.clipboard.writeText(requirePageStyles().css);
      flashButton(copyPageStylesButton, "\uD398\uC774\uC9C0 CSS \uBCF5\uC0AC\uB428", "\uD398\uC774\uC9C0 CSS \uBCF5\uC0AC");
    } catch (error) {
      renderError(`\uD398\uC774\uC9C0 CSS \uBCF5\uC0AC \uC2E4\uD328: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  function downloadPageStyles() {
    try {
      const styles = requirePageStyles();
      downloadText(
        styles.css,
        `browser-page-styles-${(/* @__PURE__ */ new Date()).toISOString().replaceAll(":", "-")}.css`,
        "text/css"
      );
      flashButton(downloadPageStylesButton, "\uD398\uC774\uC9C0 CSS \uC800\uC7A5\uB428", "\uD398\uC774\uC9C0 CSS \uC800\uC7A5");
    } catch (error) {
      renderError(`\uD398\uC774\uC9C0 CSS \uC800\uC7A5 \uC2E4\uD328: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  async function copyJson() {
    try {
      await navigator.clipboard.writeText(requireExchangeJson());
      flashButton(copyJsonButton, "JSON \uBCF5\uC0AC\uB428", "JSON \uBCF5\uC0AC");
    } catch (error) {
      renderError(
        `JSON \uD074\uB9BD\uBCF4\uB4DC \uBCF5\uC0AC \uC2E4\uD328: ${error instanceof Error ? error.message : String(error)}`
      );
    }
  }
  function downloadJson() {
    try {
      downloadText(
        requireExchangeJson(),
        `browser-layout-exchange-${(/* @__PURE__ */ new Date()).toISOString().replaceAll(":", "-")}.json`,
        "application/json"
      );
      flashButton(downloadJsonButton, "JSON \uC800\uC7A5\uB428", "JSON \uC800\uC7A5");
    } catch (error) {
      renderError(`JSON \uB0B4\uBCF4\uB0B4\uAE30 \uC2E4\uD328: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  function requireExchangeJson() {
    if (!lastState) throw new Error("\uBA3C\uC800 \uD398\uC774\uC9C0 \uC0C1\uD0DC\uB97C \uBD88\uB7EC\uC624\uC138\uC694.");
    return formatLayoutExchangeJson(lastState);
  }
  function requirePageStyles() {
    if (!lastPageStyles) throw new Error("\uBA3C\uC800 \uD398\uC774\uC9C0 \uC2A4\uD0C0\uC77C\uC744 \uCD94\uCD9C\uD558\uC138\uC694.");
    return lastPageStyles;
  }
  function downloadText(contents, filename, type) {
    const blob = new Blob([contents], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(url);
  }
  function flashButton(button, confirmation, original) {
    button.textContent = confirmation;
    globalThis.setTimeout(() => {
      button.textContent = original;
    }, 1500);
  }
  async function exportViewportPng() {
    exportPngButton.disabled = true;
    try {
      const result = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          { type: "browser-layout-inspector.capture-visible-tab" },
          (response) => {
            resolve(
              response ?? {}
            );
          }
        );
      });
      if (!result.ok || !result.dataUrl)
        throw new Error(result.error ?? "\uD604\uC7AC viewport\uB97C \uCEA1\uCC98\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
      const anchor = document.createElement("a");
      anchor.href = result.dataUrl;
      anchor.download = `browser-layout-${(/* @__PURE__ */ new Date()).toISOString().replaceAll(":", "-")}.png`;
      anchor.click();
      flashButton(exportPngButton, "PNG \uC800\uC7A5\uB428", "Viewport PNG");
    } catch (error) {
      renderError(`PNG \uB0B4\uBCF4\uB0B4\uAE30 \uC2E4\uD328: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      exportPngButton.disabled = false;
    }
  }
  function safeComment2(value) {
    return value.replaceAll("*/", "* /").replaceAll("\n", " ");
  }
  function isStateChangedMessage(message) {
    return typeof message === "object" && message !== null && message.type === "browser-layout-inspector.state-changed" && typeof message.state === "object";
  }
  function setBusy(busy) {
    for (const button of document.querySelectorAll("button")) button.disabled = busy;
    if (!busy)
      clearGuidesButton.disabled = !lastState || lastState.guides.vertical.length + lastState.guides.horizontal.length === 0;
  }
  function requiredElement(id) {
    const element = document.getElementById(id);
    if (!element) throw new Error(`popup element missing: ${id}`);
    return element;
  }
  function requiredInput(id) {
    return requiredElement(id);
  }
  function activeTabId() {
    return new Promise((resolve, reject) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tabId = tabs[0]?.id;
        if (typeof tabId !== "number") reject(new Error("\uD65C\uC131 \uD0ED\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4."));
        else resolve(tabId);
      });
    });
  }
  function sendToTab(tabId, request) {
    return new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, request, (response) => {
        if (chrome.runtime.lastError) resolve(null);
        else resolve(response ?? null);
      });
    });
  }
  function ensureContentScript(tabId) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: "browser-layout-inspector.ensure-content-script", tabId },
        (response) => {
          const result = response;
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else if (!result?.ok)
            reject(new Error(result?.error ?? "content script \uC8FC\uC785\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4."));
          else resolve();
        }
      );
    });
  }
  async function requestInTab(tabId, request) {
    const initial = await sendToTab(tabId, request);
    if (initial) return initial;
    await ensureContentScript(tabId);
    const response = await sendToTab(tabId, request);
    if (!response) throw new Error("content script \uC751\uB2F5\uC744 \uBC1B\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    return response;
  }

})();
//# sourceMappingURL=popup.js.map
//# sourceMappingURL=popup.js.map