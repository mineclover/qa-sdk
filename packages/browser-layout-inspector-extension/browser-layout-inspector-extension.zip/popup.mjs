// src/css-output.ts
function formatInspectionAsCss(inspection) {
  const selector = inspection.targetSelector ?? ":root";
  const sections = [
    "/* Computed CSS snapshot \u2014 final values for the current page state. */",
    formatRule(selector, Object.entries(inspection.computedStyle.properties).map(([property, value]) => ({ property, value, priority: "" })), false)
  ];
  const influences = inspection.cssInfluences;
  if (!influences) return sections.join("\n\n");
  if (influences.inlineStyle.length > 0) {
    sections.push("/* Existing inline style before any extension edit. */", formatRule(selector, influences.inlineStyle, false));
  }
  if (influences.matchedSelectors.length > 0) {
    sections.push("/* Matched author CSS candidates \u2014 inspect the computed block above for final winners. */");
    for (const match of influences.matchedSelectors) sections.push(formatSourceRule(match));
  }
  if (influences.inaccessibleStylesheets.length > 0) {
    sections.push(`/* CSSOM unavailable: ${influences.inaccessibleStylesheets.map((sheet) => safeComment(sheet.stylesheetHref ?? sheet.stylesheetLabel)).join(", ")} */`);
  }
  return sections.join("\n\n");
}
function formatSourceRule(match) {
  const source = match.stylesheetHref ?? match.stylesheetLabel;
  const conditions = match.conditions.length > 0 ? `; active when ${match.conditions.join(" \u2192 ")}` : "";
  return `/* Source: ${safeComment(source)}${safeComment(conditions)} */
${formatRule(match.selector, match.declarations, true)}`;
}
function formatRule(selector, declarations, keepEmpty) {
  const lines = declarations.filter((declaration) => keepEmpty || declaration.value !== "").map((declaration) => `  ${declaration.property}: ${declaration.value}${declaration.priority ? ` !${declaration.priority}` : ""};`);
  return `${selector} {
${lines.join("\n")}
}`;
}
function safeComment(value) {
  return value.replaceAll("*/", "* /").replaceAll("\n", " ");
}

// src/json-output.ts
function createLayoutExchange(state, exportedAt = (/* @__PURE__ */ new Date()).toISOString()) {
  return {
    schemaVersion: "browser-layout-inspector.exchange.v1",
    exportedAt,
    environment: state.environment,
    selected: state.selected,
    inspection: state.inspection,
    elementMeasurement: state.measurement,
    ruler: state.ruler,
    rulerSnapEnabled: state.rulerSnapEnabled,
    guides: state.guides,
    changedElementCount: state.changedElementCount
  };
}
function formatLayoutExchangeJson(state) {
  return `${JSON.stringify(createLayoutExchange(state), null, 2)}
`;
}

// src/popup.ts
var output = requiredElement("output");
var selection = requiredElement("selection");
var pickSelectButton = requiredElement("pick-select");
var pickMeasureButton = requiredElement("pick-measure");
var rulerButton = requiredElement("ruler");
var rulerSnapInput = requiredElement("ruler-snap");
var pinGuidesButton = requiredElement("pin-guides");
var clearGuidesButton = requiredElement("clear-guides");
var guideCount = requiredElement("guide-count");
var copyCssButton = requiredElement("copy-css");
var copyJsonButton = requiredElement("copy-json");
var downloadJsonButton = requiredElement("download-json");
var exportPngButton = requiredElement("export-png");
var refreshButton = requiredElement("refresh");
var styleProperty = requiredInput("style-property");
var styleValue = requiredInput("style-value");
var applyStyleButton = requiredElement("apply-style");
var hideButton = requiredElement("hide-selected");
var restoreSelectedButton = requiredElement("restore-selected");
var restoreAllButton = requiredElement("restore-all");
var selectorInput = requiredInput("selector");
var referenceInput = requiredInput("reference-selector");
var propertiesInput = requiredInput("properties");
var inspectButton = requiredElement("inspect");
var lastState = null;
pickSelectButton.addEventListener("click", () => void run({ type: "browser-layout-inspector.start-picker", mode: "select" }, "\uD398\uC774\uC9C0\uC5D0\uC11C \uC694\uC18C\uB97C \uD074\uB9AD\uD574 \uC120\uD0DD\uD558\uC138\uC694. Side Panel\uC740 \uC5F4\uB9B0 \uC0C1\uD0DC\uB85C \uC720\uC9C0\uB429\uB2C8\uB2E4."));
pickMeasureButton.addEventListener("click", () => void run({ type: "browser-layout-inspector.start-picker", mode: "measure" }, "\uAE30\uC900 A\uC640 \uB300\uC0C1 B\uB97C \uCC28\uB840\uB85C \uD074\uB9AD\uD558\uC138\uC694. Side Panel\uC5D0\uC11C \uACB0\uACFC\uAC00 \uC790\uB3D9 \uAC31\uC2E0\uB429\uB2C8\uB2E4."));
rulerButton.addEventListener("click", () => void run({ type: "browser-layout-inspector.start-picker", mode: "ruler" }, "\uD398\uC774\uC9C0\uC5D0\uC11C \uC2DC\uC791\uC810\uBD80\uD130 \uB05D\uC810\uAE4C\uC9C0 \uB4DC\uB798\uADF8\uD558\uC138\uC694. \uC694\uC18C\uB97C \uC120\uD0DD\uD558\uC9C0 \uC54A\uB294 \uC790\uC720 Ruler\uC785\uB2C8\uB2E4."));
rulerSnapInput.addEventListener("change", () => void run({ type: "browser-layout-inspector.set-ruler-snap", enabled: rulerSnapInput.checked }));
pinGuidesButton.addEventListener("click", () => void run({ type: "browser-layout-inspector.pin-ruler-guides" }));
clearGuidesButton.addEventListener("click", () => void run({ type: "browser-layout-inspector.clear-ruler-guides" }));
copyCssButton.addEventListener("click", () => void copyCss());
copyJsonButton.addEventListener("click", () => void copyJson());
downloadJsonButton.addEventListener("click", () => downloadJson());
exportPngButton.addEventListener("click", () => void exportViewportPng());
refreshButton.addEventListener("click", () => void run({ type: "browser-layout-inspector.get-state" }));
applyStyleButton.addEventListener("click", () => void run({
  type: "browser-layout-inspector.apply-style",
  property: styleProperty.value,
  value: styleValue.value
}));
hideButton.addEventListener("click", () => void run({ type: "browser-layout-inspector.hide-selected" }));
restoreSelectedButton.addEventListener("click", () => void run({ type: "browser-layout-inspector.restore-selected" }));
restoreAllButton.addEventListener("click", () => void run({ type: "browser-layout-inspector.restore-all" }));
inspectButton.addEventListener("click", () => {
  const selector = selectorInput.value.trim();
  if (!selector) return renderError("CSS selector\uB97C \uC785\uB825\uD558\uC138\uC694.");
  void run({
    type: "browser-layout-inspector.inspect-selector",
    selector,
    ...referenceInput.value.trim() ? { referenceSelector: referenceInput.value.trim() } : {},
    ...propertiesInput.value.trim() ? { computedProperties: propertiesInput.value.split(",").map((property) => property.trim()).filter(Boolean) } : {}
  });
});
void run({ type: "browser-layout-inspector.get-state" });
chrome.runtime.onMessage.addListener((message) => {
  if (!isStateChangedMessage(message)) return;
  renderState(message.state);
});
async function run(request, notice) {
  setBusy(true);
  try {
    const tabId = await activeTabId();
    const response = await requestInTab(tabId, request);
    render(response, notice);
  } catch (error) {
    renderError(error instanceof Error ? error.message : String(error));
  } finally {
    setBusy(false);
  }
}
function render(response, notice) {
  if (!response.ok) return renderError(response.error ?? "\uC694\uCCAD\uC744 \uCC98\uB9AC\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
  if ("state" in response && response.state) renderState(response.state, notice);
  else if ("inspection" in response) {
    selection.textContent = response.inspection?.targetSelector ?? "\uC218\uB3D9 \uAC80\uC0AC \uACB0\uACFC";
    output.textContent = response.inspection ? formatInspectionAsCss(response.inspection) : "/* \uAC80\uC0AC \uACB0\uACFC\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. */";
  }
}
function renderState(state, notice) {
  lastState = state;
  selection.textContent = state.selected ? `${state.selected.selector} (${state.selected.tagName})` : "\uC120\uD0DD\uB41C \uC694\uC18C \uC5C6\uC74C";
  rulerSnapInput.checked = state.rulerSnapEnabled;
  guideCount.textContent = `\uAC00\uC774\uB4DC ${state.guides.vertical.length + state.guides.horizontal.length}\uAC1C`;
  output.textContent = formatStateAsCss(state, notice);
}
function renderError(error) {
  output.textContent = `/* \uC624\uB958: ${safeComment2(error)} */`;
}
function formatStateAsCss(state, notice) {
  const notes = [
    notice ? `\uC0C1\uD0DC: ${notice}` : null,
    state.pickerMode ? `\uB3C4\uAD6C: ${state.pickerMode} \uD65C\uC131` : null,
    state.measurement ? `A \u2192 B DOM edge gap \u2014 \u0394x ${state.measurement.relative.deltaCssPx?.x ?? "n/a"}px, \u0394y ${state.measurement.relative.deltaCssPx?.y ?? "n/a"}px; A.right \u2192 B.left ${state.measurement.relative.edgeGapsCssPx?.leftToRight ?? "n/a"}px; A.bottom \u2192 B.top ${state.measurement.relative.edgeGapsCssPx?.topToBottom ?? "n/a"}px.` : null,
    state.ruler ? `Ruler viewport \u2014 start (${state.ruler.start.x}, ${state.ruler.start.y}), end (${state.ruler.end.x}, ${state.ruler.end.y}); width ${state.ruler.width}px; height ${state.ruler.height}px; diagonal ${state.ruler.distance}px.` : null,
    state.ruler ? `Ruler angle: ${state.ruler.angle}\xB0; 8px snap ${state.rulerSnapEnabled ? "on" : "off"}; persistent guides ${state.guides.vertical.length + state.guides.horizontal.length}.` : null,
    state.changedElementCount > 0 ? `\uC784\uC2DC inline \uBCC0\uACBD \uC694\uC18C: ${state.changedElementCount}\uAC1C (\uC6D0\uBCF5 \uAC00\uB2A5)` : null
  ].filter((note) => note !== null);
  const inspection = state.inspection ? formatInspectionAsCss(state.inspection) : "/* \uD398\uC774\uC9C0\uC5D0\uC11C \uC694\uC18C\uB97C \uC120\uD0DD\uD558\uBA74 copyable computed CSS\uAC00 \uD45C\uC2DC\uB429\uB2C8\uB2E4. */";
  return `${notes.length > 0 ? `/*
${notes.map((note) => ` * ${safeComment2(note)}`).join("\n")}
 */

` : ""}${inspection}`;
}
async function copyCss() {
  try {
    await navigator.clipboard.writeText(output.textContent ?? "");
    flashButton(copyCssButton, "\uBCF5\uC0AC\uB428", "CSS \uBCF5\uC0AC");
  } catch (error) {
    renderError(`\uD074\uB9BD\uBCF4\uB4DC \uBCF5\uC0AC \uC2E4\uD328: ${error instanceof Error ? error.message : String(error)}`);
  }
}
async function copyJson() {
  try {
    await navigator.clipboard.writeText(requireExchangeJson());
    flashButton(copyJsonButton, "JSON \uBCF5\uC0AC\uB428", "JSON \uBCF5\uC0AC");
  } catch (error) {
    renderError(`JSON \uD074\uB9BD\uBCF4\uB4DC \uBCF5\uC0AC \uC2E4\uD328: ${error instanceof Error ? error.message : String(error)}`);
  }
}
function downloadJson() {
  try {
    const blob = new Blob([requireExchangeJson()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `browser-layout-exchange-${(/* @__PURE__ */ new Date()).toISOString().replaceAll(":", "-")}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    flashButton(downloadJsonButton, "JSON \uC800\uC7A5\uB428", "JSON \uC800\uC7A5");
  } catch (error) {
    renderError(`JSON \uB0B4\uBCF4\uB0B4\uAE30 \uC2E4\uD328: ${error instanceof Error ? error.message : String(error)}`);
  }
}
function requireExchangeJson() {
  if (!lastState) throw new Error("\uBA3C\uC800 \uD398\uC774\uC9C0 \uC0C1\uD0DC\uB97C \uBD88\uB7EC\uC624\uC138\uC694.");
  return formatLayoutExchangeJson(lastState);
}
function flashButton(button, confirmation, original) {
  button.textContent = confirmation;
  globalThis.setTimeout(() => {
    button.textContent = original;
  }, 1500);
}
async function exportViewportPng() {
  exportPngButton.disabled = true;
  try {
    const result = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "browser-layout-inspector.capture-visible-tab" }, (response) => {
        resolve(response ?? {});
      });
    });
    if (!result.ok || !result.dataUrl) throw new Error(result.error ?? "\uD604\uC7AC viewport\uB97C \uCEA1\uCC98\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    const anchor = document.createElement("a");
    anchor.href = result.dataUrl;
    anchor.download = `browser-layout-${(/* @__PURE__ */ new Date()).toISOString().replaceAll(":", "-")}.png`;
    anchor.click();
    flashButton(exportPngButton, "PNG \uC800\uC7A5\uB428", "Viewport PNG");
  } catch (error) {
    renderError(`PNG \uB0B4\uBCF4\uB0B4\uAE30 \uC2E4\uD328: ${error instanceof Error ? error.message : String(error)}`);
  } finally {
    exportPngButton.disabled = false;
  }
}
function safeComment2(value) {
  return value.replaceAll("*/", "* /").replaceAll("\n", " ");
}
function isStateChangedMessage(message) {
  return typeof message === "object" && message !== null && message.type === "browser-layout-inspector.state-changed" && typeof message.state === "object";
}
function setBusy(busy) {
  for (const button of document.querySelectorAll("button")) button.disabled = busy;
}
function requiredElement(id) {
  const element = document.getElementById(id);
  if (!element) throw new Error(`popup element missing: ${id}`);
  return element;
}
function requiredInput(id) {
  return requiredElement(id);
}
function activeTabId() {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      if (typeof tabId !== "number") reject(new Error("\uD65C\uC131 \uD0ED\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4."));
      else resolve(tabId);
    });
  });
}
function sendToTab(tabId, request) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, request, (response) => {
      if (chrome.runtime.lastError) resolve(null);
      else resolve(response ?? null);
    });
  });
}
function ensureContentScript(tabId) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: "browser-layout-inspector.ensure-content-script", tabId }, (response) => {
      const result = response;
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else if (!result?.ok) reject(new Error(result?.error ?? "content script \uC8FC\uC785\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4."));
      else resolve();
    });
  });
}
async function requestInTab(tabId, request) {
  const initial = await sendToTab(tabId, request);
  if (initial) return initial;
  await ensureContentScript(tabId);
  const response = await sendToTab(tabId, request);
  if (!response) throw new Error("content script \uC751\uB2F5\uC744 \uBC1B\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
  return response;
}
//# sourceMappingURL=popup.mjs.map
//# sourceMappingURL=popup.mjs.map